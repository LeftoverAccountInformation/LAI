soot-infoflow-android
=====================
soot-infoflow-android is part of FlowDroid, a context-, flow-, field-, object-sensitive and lifecycle-aware static taint analysis tool for Android applications.

A manual can be found here: https://github.com/secure-software-engineering/soot-infoflow-android/wiki

For more information visit http://sseblog.ec-spride.de/android/flowdroid/
