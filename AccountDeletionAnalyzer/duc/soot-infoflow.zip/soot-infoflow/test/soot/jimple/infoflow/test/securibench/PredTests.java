/*******************************************************************************
 * Copyright (c) 2012 Secure Software Engineering Group at EC SPRIDE.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Lesser Public License v2.1
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * 
 * Contributors: Christian Fritz, Steven Arzt, Siegfried Rasthofer, Eric
 * Bodden, and others.
 ******************************************************************************/
package soot.jimple.infoflow.test.securibench;


public class PredTests extends JUnitTests {
//	@Test
//	public void pred1() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.pred.Pred1: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	negativeCheckInfoflow(infoflow);
//	}
//
//	@Test
//	public void pred2() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.pred.Pred2: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}
//
//	@Test
//	public void pred3() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.pred.Pred3: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	negativeCheckInfoflow(infoflow);
//	}
//
//	@Test
//	public void pred4() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.pred.Pred4: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}
//
//	@Test
//	public void pred5() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.pred.Pred5: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}
//
//	@Test
//	public void pred6() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.pred.Pred6: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	negativeCheckInfoflow(infoflow);
//	}
//
//	@Test
//	public void pred7() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.pred.Pred7: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	negativeCheckInfoflow(infoflow);
//	}
//
//	@Test
//	public void pred8() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.pred.Pred8: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}
//
//	@Test
//	public void pred9() {
//	Infoflow infoflow = initInfoflow();
//	List<String> epoints = new ArrayList<String>();
//	epoints.add("<securibench.micro.pred.Pred9: void doGet(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>");
//	infoflow.computeInfoflow(path, entryPointCreator, epoints, sources, sinks);
//	checkInfoflow(infoflow);
//	}


}
