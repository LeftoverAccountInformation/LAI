/*******************************************************************************
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Lesser Public License v2.1
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * 
 * Contributors: Christian Fritz, Steven Arzt, Siegfried Rasthofer, Eric
 * Bodden, and others.
 ******************************************************************************/
package soot.jimple.infoflow;

import heros.solver.CountingThreadPoolExecutor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap; 
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map; 
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.Random;

import jlibs.core.lang.RuntimeUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xmlpull.v1.XmlPullParserException;

import soot.Local;
import soot.MethodOrMethodContext;
import soot.PackManager;
import soot.PatchingChain;
import soot.PointsToAnalysis;
import soot.PointsToSet;
import soot.Scene;
import soot.SootClass;
import soot.SootField;
import soot.SootMethod;
import soot.Transform;
import soot.Unit;
import soot.Value;
import soot.jimple.ArrayRef;
import soot.jimple.AssignStmt;
import soot.jimple.DefinitionStmt;
import soot.jimple.FieldRef;
import soot.jimple.InstanceFieldRef;
import soot.jimple.InvokeExpr;
import soot.jimple.IdentityStmt;
import soot.jimple.StaticFieldRef;
import soot.jimple.Stmt;
import soot.jimple.ParameterRef;
import soot.jimple.infoflow.InfoflowResults.SinkInfo;
import soot.jimple.infoflow.InfoflowResults.SourceInfo;
import soot.jimple.infoflow.aliasing.Aliasing;
import soot.jimple.infoflow.aliasing.FlowSensitiveAliasStrategy;
import soot.jimple.infoflow.aliasing.IAliasingStrategy;
import soot.jimple.infoflow.aliasing.PtsBasedAliasStrategy;
import soot.jimple.infoflow.android.data.AndroidMethod;       
import soot.jimple.infoflow.android.AndroidSourceSinkManager;  
import soot.jimple.infoflow.android.TestApps.Test;       
import soot.jimple.infoflow.config.IInfoflowConfig;
import soot.jimple.infoflow.data.AbstractionAtSink;
import soot.jimple.infoflow.data.AccessPath;
import soot.jimple.infoflow.data.pathBuilders.DefaultPathBuilderFactory;
import soot.jimple.infoflow.data.pathBuilders.IAbstractionPathBuilder;
import soot.jimple.infoflow.data.pathBuilders.IPathBuilderFactory;
import soot.jimple.infoflow.entryPointCreators.IEntryPointCreator;
import soot.jimple.infoflow.handlers.ResultsAvailableHandler;
import soot.jimple.infoflow.handlers.TaintPropagationHandler;
import soot.jimple.infoflow.ipc.DefaultIPCManager;
import soot.jimple.infoflow.ipc.IIPCManager;
import soot.jimple.infoflow.problems.BackwardsInfoflowProblem;
import soot.jimple.infoflow.problems.InfoflowProblem;
import soot.jimple.infoflow.solver.BackwardsInfoflowCFG;
import soot.jimple.infoflow.solver.IInfoflowCFG;
import soot.jimple.infoflow.solver.fastSolver.InfoflowSolver;
import soot.jimple.infoflow.source.ISourceSinkManager;
import soot.jimple.infoflow.util.SootMethodRepresentationParser;
import soot.jimple.infoflow.util.SystemClassHandler;
import soot.jimple.toolkits.callgraph.ReachableMethods;
import soot.options.Options;
import android.view.View;
import android.content.Context;
/**
 * main infoflow class which triggers the analysis and offers method to customize it.
 *
 */
public class Infoflow extends AbstractInfoflow {
	
    private final Logger logger = LoggerFactory.getLogger(getClass());
    
	private static int accessPathLength = 5;
	private static boolean useRecursiveAccessPaths = true;
	private static boolean pathAgnosticResults = true;
	
	private InfoflowResults results = null;
	private final IPathBuilderFactory pathBuilderFactory;

	private final String androidPath;
	private final boolean forceAndroidJar;
	private IInfoflowConfig sootConfig;
	
	private IIPCManager ipcManager = new DefaultIPCManager(new ArrayList<String>());
	
    private IInfoflowCFG iCfg;
    
    private Set<ResultsAvailableHandler> onResultsAvailable = new HashSet<ResultsAvailableHandler>();
    private Set<TaintPropagationHandler> taintPropagationHandlers = new HashSet<TaintPropagationHandler>();

    public static Set<SootField> fieldSet = new HashSet<SootField>();  
    public static Set<SootClass> activities = new HashSet<SootClass>();
    public static Map<Local,SootMethod> localMap = new HashMap<Local,SootMethod>();
    public static Set<Value> arraySet = new HashSet<Value>();
    public static Set<Unit> changeSet = new HashSet<Unit>();
    public static int sinkCount = 0;
    public static Set<Unit> exits = new HashSet<Unit>();
    public static Set<Unit> changes = new HashSet<Unit>();
    public static Set<Unit> aliasChanges = new HashSet<Unit>();
    public static Set<Unit> apiCalls = new HashSet<Unit>();
    public static Set<Unit> setCalls = new HashSet<Unit>();
    public static Set<Unit> storeCalls = new HashSet<Unit>();
    public static Set<Unit> restoreCalls = new HashSet<Unit>();
    public static Set<Unit> selectedChanges = new HashSet<Unit>();
    public static Set<Unit> selectedChanges_restore = new HashSet<Unit>();
    public static Set<Unit> selectedChanges_api = new HashSet<Unit>();
    public static Set<Unit> acquireCalls = new HashSet<Unit>();
    public static Set<Unit> releaseCalls = new HashSet<Unit>();
    public static Set<SootField> allFields = new HashSet<SootField>();
    public static Set<SootField> fields = new HashSet<SootField>();
    public static Map<PointsToSet,Set<SootField>> ptsFields = new HashMap<PointsToSet,Set<SootField>>();
    public static Map<SootField,Set<Unit>> fieldChanges = new HashMap<SootField,Set<Unit>>();
    public static Map<Unit,Set<SootField>> changeFields = new HashMap<Unit,Set<SootField>>();
    public static Set<SootField> selectedFields = new HashSet<SootField>();
    public static Set<SootField> selectedFields_restore = new HashSet<SootField>();
    public static Set<SootField> guaranteedFields = new HashSet<SootField>();
    public static Set<SootField> KR1Fields1 = new HashSet<SootField>();
    public static Set<SootField> KR1Fields2 = new HashSet<SootField>();
    public static Set<SootField> KR2Fields = new HashSet<SootField>();
    public static Set<SootField> KR3Fields = new HashSet<SootField>();
    public static Set<SootField> KR4Fields = new HashSet<SootField>();  //guaranteed loss
    public static Set<Unit> unsavedChanges = new HashSet<Unit>();
    private static Map<String,Integer> maxMap = new HashMap<String,Integer>();
    
    class callChangePath{
    	public Unit call;
    	public Unit change;
    	public List<Stmt> path;
    	public callChangePath(Unit call, Unit change, List<Stmt> path){
    		this.call = call;
    		this.change = change;
    		this.path = path;
    	}
    }
    public List<callChangePath> callChangePaths = new ArrayList<callChangePath>();
    public List<callChangePath> apiCallChangePaths = new ArrayList<callChangePath>();
    public List<callChangePath> changeStoreCallPaths = new ArrayList<callChangePath>();
    
    class changePath{
    	public Unit change;
    	public List<Unit> path;
    	public changePath(Unit change, Stack<Unit> path){
    		this.change = change;
    		this.path = new Stack<Unit>();
    		this.path.addAll(path);
    	}
    }
    public List<changePath> unsavedChangePaths = new ArrayList<changePath>();
    
	/**
	 * Creates a new instance of the InfoFlow class for analyzing plain Java code without any references to APKs or the Android SDK.
	 */
	public Infoflow() {
		this.androidPath = "";
		this.forceAndroidJar = false;
		this.pathBuilderFactory = new DefaultPathBuilderFactory();
	}

	/**
	 * Creates a new instance of the Infoflow class for analyzing Android APK files.
	 * @param androidPath If forceAndroidJar is false, this is the base directory
	 * of the platform files in the Android SDK. If forceAndroidJar is true, this
	 * is the full path of a single android.jar file.
	 * @param forceAndroidJar True if a single platform JAR file shall be forced,
	 * false if Soot shall pick the appropriate platform version 
	 */
	public Infoflow(String androidPath, boolean forceAndroidJar) {
		super();
		this.androidPath = androidPath;
		this.forceAndroidJar = forceAndroidJar;
		this.pathBuilderFactory = new DefaultPathBuilderFactory();
	}

	/**
	 * Creates a new instance of the Infoflow class for analyzing Android APK files.
	 * @param androidPath If forceAndroidJar is false, this is the base directory
	 * of the platform files in the Android SDK. If forceAndroidJar is true, this
	 * is the full path of a single android.jar file.
	 * @param forceAndroidJar True if a single platform JAR file shall be forced,
	 * false if Soot shall pick the appropriate platform version
	 * @param icfgFactory The interprocedural CFG to be used by the InfoFlowProblem
	 * @param pathBuilderFactory The factory class for constructing a path builder
	 * algorithm 
	 */
	public Infoflow(String androidPath, boolean forceAndroidJar, BiDirICFGFactory icfgFactory,
			IPathBuilderFactory pathBuilderFactory) {
		super(icfgFactory);
		this.androidPath = androidPath;
		this.forceAndroidJar = forceAndroidJar;
		this.pathBuilderFactory = pathBuilderFactory;
	}
	
	public void setSootConfig(IInfoflowConfig config){
		sootConfig = config;
	}
	
	/**
	 * Initializes Soot.
	 * @param appPath The application path containing the analysis client
	 * @param libPath The Soot classpath containing the libraries
	 * @param classes The set of classes that shall be checked for data flow
	 * analysis seeds. All sources in these classes are used as seeds.
	 * @param sourcesSinks The manager object for identifying sources and sinks
	 */
	private void initializeSoot(String appPath, String libPath, Set<String> classes) {
		initializeSoot(appPath, libPath, classes,  "");
	}
	
	/**
	 * Initializes Soot.
	 * @param appPath The application path containing the analysis client
	 * @param libPath The Soot classpath containing the libraries
	 * @param classes The set of classes that shall be checked for data flow
	 * analysis seeds. All sources in these classes are used as seeds. If a
	 * non-empty extra seed is given, this one is used too.
	 */
	private void initializeSoot(String appPath, String libPath, Set<String> classes,
			String extraSeed) {
		// reset Soot:
		logger.info("Resetting Soot...");
		soot.G.reset();
				
		Options.v().set_no_bodies_for_excluded(true);
		Options.v().set_allow_phantom_refs(true);
		
		if (logger.isDebugEnabled())
			Options.v().set_output_format(Options.output_format_jimple);
		else
			Options.v().set_output_format(Options.output_format_none);
		
		// We only need to distinguish between application and library classes
		// if we use the OnTheFly ICFG
		if (callgraphAlgorithm == CallgraphAlgorithm.OnDemand) {
			Options.v().set_soot_classpath(libPath);
			if (appPath != null) {
				List<String> processDirs = new LinkedList<String>();
				for (String ap : appPath.split(File.pathSeparator))
					processDirs.add(ap);
				Options.v().set_process_dir(processDirs);
			}
		}
		else
			Options.v().set_soot_classpath(appPath + File.pathSeparator + libPath);
		
		// Configure the callgraph algorithm
		switch (callgraphAlgorithm) {
			case AutomaticSelection:
				// If we analyze a distinct entry point which is not static,
				// SPARK fails due to the missing allocation site and we fall
				// back to CHA.
				if (extraSeed == null || extraSeed.isEmpty()) {
					Options.v().setPhaseOption("cg.spark", "on");
					Options.v().setPhaseOption("cg.spark", "string-constants:true");
				}
				else
					Options.v().setPhaseOption("cg.cha", "on");
				break;
			case CHA:
				Options.v().setPhaseOption("cg.cha", "on");
				break;
			case RTA:
				Options.v().setPhaseOption("cg.spark", "on");
				Options.v().setPhaseOption("cg.spark", "rta:true");
				Options.v().setPhaseOption("cg.spark", "string-constants:true");
				break;
			case VTA:
				Options.v().setPhaseOption("cg.spark", "on");
				Options.v().setPhaseOption("cg.spark", "vta:true");
				Options.v().setPhaseOption("cg.spark", "string-constants:true");
				break;
			case SPARK:
				Options.v().setPhaseOption("cg.spark", "on");
				Options.v().setPhaseOption("cg.spark", "string-constants:true");
				break;
			case OnDemand:
				// nothing to set here
				break;
			default:
				throw new RuntimeException("Invalid callgraph algorithm");
		}
		
		// Specify additional options required for the callgraph
		if (callgraphAlgorithm != CallgraphAlgorithm.OnDemand) {
			Options.v().set_whole_program(true);
			Options.v().setPhaseOption("cg", "trim-clinit:false");
		}

		// do not merge variables (causes problems with PointsToSets)
		Options.v().setPhaseOption("jb.ulp", "off");
		
		if (!this.androidPath.isEmpty()) {
			Options.v().set_src_prec(Options.src_prec_apk);
			if (this.forceAndroidJar)
				soot.options.Options.v().set_force_android_jar(this.androidPath);
			else
				soot.options.Options.v().set_android_jars(this.androidPath);
		} else
			Options.v().set_src_prec(Options.src_prec_java);
		
		//at the end of setting: load user settings:
		if (sootConfig != null)
			sootConfig.setSootOptions(Options.v());
		
		// load all entryPoint classes with their bodies
		Scene.v().loadNecessaryClasses();
		logger.info("Basic class loading done.");
		boolean hasClasses = false;
		for (String className : classes) {
			SootClass c = Scene.v().forceResolve(className, SootClass.BODIES);
			if (c != null){
				c.setApplicationClass();
				if(!c.isPhantomClass() && !c.isPhantom())
					hasClasses = true;
			}
		}
		if (!hasClasses) {
			logger.error("Only phantom classes loaded, skipping analysis...");
			return;
		}
	}

	private Stack<Unit> callStack = new Stack<Unit>();
	private Stack<Unit> execPath;
	public Map<Unit,Set<Unit>> mapCallToChanges = new HashMap<Unit, Set<Unit>>();
	public Map<Unit,Set<Unit>> mapChangeToStoreCalls = new HashMap<Unit, Set<Unit>>();
	public Map<Unit,Set<Unit>> mapApiCallToChanges = new HashMap<Unit, Set<Unit>>();
	private int level =0;
	
	private boolean TravelSuccsOf(Unit u, int level){
		for(Unit cu : iCfg.getSuccsOf(u)){
			if(TravelCFGForChange(cu,level)==true){
				return true;
			}else{  //TravelCFGForChange returns false
				while(!execPath.isEmpty()){
					if(execPath.pop().equals(cu)){
						break;
					}
				}
			}
			if(!foundStoreCall && u.toString().contains("java.util.Iterator: java.lang.Object next()")){  // jump out of loop
				if(TravelCFGForChange(iCfg.getPostdominatorOf(u).getUnit(),level)==true)
					return true;
				else
					break;
			}
		}
		return false;
	}

	private boolean foundStoreCall = false;
	private Unit branchPoint;
	private List<Unit> oldBranchPoints = new ArrayList<Unit>();

	private boolean computeBranchPoint(){
		for(int index=execPath.size()-2;index>=0;index--){
			Unit ui = execPath.get(index);
			if((iCfg.getSuccsOf(ui).size()>1)&&(!ui.toString().contains("java.util.Iterator: java.lang.Object next()"))){
				int pd = execPath.lastIndexOf(iCfg.getPostdominatorOf(ui).getUnit());
				if(pd==-1){
					int count = 0;
					for(Unit op : oldBranchPoints){
						if(op.equals(ui))
							count++;
					}
					if(count < iCfg.getSuccsOf(ui).size()){
						branchPoint = ui;
						oldBranchPoints.add(ui);
						//logger.info("branchPoint is {} in method: {}",branchPoint,iCfg.getMethodOf(branchPoint));
						return true;
					}
				}
			}
		}
		return false;
	}
	
	private boolean handleStatement(Unit source, int level){
		execPath.push(source);	
		//logger.info("execPath push {}, in method {}",source,iCfg.getMethodOf(source).getName());
		
		if(exits.contains(source)){
			if(iCfg.isExitStmt(source)&&iCfg.getMethodOf(source).getName().equals("dummyMainMethod"))
				logger.info("Reached the end of the main function.");
			
			return true;
		}else if(storeCalls.contains(source)){
			if(!mapChangeToStoreCalls.isEmpty() && mapChangeToStoreCalls.get(execPath.get(0))!=null)
				if(mapChangeToStoreCalls.get(execPath.get(0)).contains(source)){
					if(computeBranchPoint()==true){
						logger.info("foundStoreCall {}, in method {}",source.toString(),iCfg.getMethodOf(source));
						foundStoreCall = true;
					}else{
						logger.info("The change is properly stored!!!!!!!!!!!!!!!!!!!!!!!!!!");
						return true;
					}
				}
			return false; 
		}else if(iCfg.isCallStmt((Stmt)source)){
			SootMethod sm = ((Stmt)source).getInvokeExpr().getMethod();
			if(sm!=null){
				if((taintWrapper != null) &&
					(!taintWrapper.isWrappedClass(sm.getDeclaringClass()))){
							//!(sm.getName().contains("iterator")&&sm.getReturnType().toString().contains("java.util.Iterator")))){  //do not enter wrapper functions
					if(!((Stmt)source).toString().contains("interfaceinvoke")){
						if(!iCfg.getStartPointsOf(sm).isEmpty())
							callStack.push(source);
					}
					if(!iCfg.getStartPointsOf(sm).isEmpty()){
						level++;
						for(Unit u : iCfg.getStartPointsOf(sm)){
							if(TravelCFGForChange(u,level)==true)
								return true;
							else{
								while(!execPath.isEmpty()){
									if(execPath.pop().equals(u)){
										break;
									}
								}
							}
						}
					}
				}
			}
		}else if(iCfg.isExitStmt((Stmt)source)){
			SootMethod m = iCfg.getMethodOf(source);
			if(!callStack.empty()){
				boolean match = false;
				for(Unit caller : iCfg.getCallersOf(m)){
					if(((Stmt)caller).containsInvokeExpr() && ((Stmt)callStack.peek()).containsInvokeExpr())
						if(((Stmt)caller).getInvokeExpr().getMethod().equals(((Stmt)callStack.peek()).getInvokeExpr().getMethod())||
								((Stmt)caller).getJavaSourceStartLineNumber()==(((Stmt)callStack.peek()).getJavaSourceStartLineNumber())){
							match = true;
							break;
						}
				}
				if(match){
					Unit u4 = callStack.pop();
					level--;
					if(TravelSuccsOf(u4,level)==true)
						return true;
					else if(foundStoreCall){
						callStack.push(u4);
					}
				}else{
					mismatch=1;
				}
			}else{
				if(m != null){
					for(Unit u : iCfg.getCallersOf(m)){
						if(u!=null){
							
							level++;
							if(TravelSuccsOf(u,level)==true)
								return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	private boolean error = false;
	private int mismatch = 0;
	public boolean TravelCFGForChange(Unit su, int level){
		if(su==null)
			return false;
		level++;
		
		do{
			if(handleStatement(su,level)==true)
				return true;
			else if(foundStoreCall){
				SootMethod m = iCfg.getMethodOf(su);
				if(!callStack.empty()&&(execPath.lastIndexOf(branchPoint)<execPath.lastIndexOf(callStack.peek()))){
						if(m.equals(((Stmt)callStack.peek()).getInvokeExpr().getMethod())){   //match stack top
							callStack.pop();
							level--;
						}
				}
				return false;
			}
			
			if(iCfg.getSuccsOf(su).size()==1)
				su = iCfg.getSuccsOf(su).get(0);
			else{
				break;
			}
		}while(true);
		
			
		for(Unit cu : iCfg.getSuccsOf(su)){
			if(TravelCFGForChange(cu,level)==true){
				return true;
			}else{  //TravelCFGForChange returns false
				if(foundStoreCall && branchPoint.equals(su)){
					foundStoreCall = false;
				}
				while(!execPath.isEmpty()){
					if(execPath.pop().equals(cu)){
						break;
					}
				}
			}
			
		}

		if(!callStack.empty()){
			callStack.pop();
		}
		level--;
		return false;
	}

	public boolean TravelCFGForRelease(Unit source, int level){
		if(source==null)
			return false;
		logger.info("statementR{}: {} in method: {}",level,source,iCfg.getMethodOf(source));
		if(exits.contains(source)){
			return true;
		}else if(storeCalls.contains(source)){
			return false; 
		}else if(iCfg.isCallStmt((Stmt)source)){
			SootMethod sm = ((Stmt)source).getInvokeExpr().getMethod();
			if(sm!=null){
				if((taintWrapper != null) && (!taintWrapper.isWrappedClass(sm.getDeclaringClass()))){
					if(!((Stmt)source).toString().contains("interfaceinvoke")){
						callStack.push(source);
						//logger.info("Callee Method: {}, push Stack: {}, size={}",sm,source,callStack.size());
					}
					level++;
					for(Unit u : iCfg.getStartPointsOf(sm)){
						if(TravelCFGForRelease(u,level)==true)
							return true;
					}
				}
			}
		}else if(iCfg.isExitStmt((Stmt)source)){
			SootMethod m = iCfg.getMethodOf(source);
			if(!callStack.empty()){
				boolean match = false;
				for(Unit caller : iCfg.getCallersOf(m)){
					if(((Stmt)caller).getInvokeExpr().equals(((Stmt)callStack.peek()).getInvokeExpr())&&
							((Stmt)caller).getJavaSourceStartLineNumber()==(((Stmt)callStack.peek()).getJavaSourceStartLineNumber())){
						match = true;
						break;
					}
				}
				if(match){
					logger.info("Stack pop: {}",callStack.peek());
					Unit u4 = callStack.pop();
					level--;
		
					for(Unit u5 : iCfg.getSuccsOf(u4)){
						if(u5!=null){
							if(TravelCFGForRelease(u5,level)==true)
								return true;
						}
					}	
				}else{
					logger.info("Stack mismatch: {},  callers: {}",callStack.peek(),iCfg.getCallersOf(m));
				}
			}else{
				if(m != null){
					for(Unit u : iCfg.getCallersOf(m)){
						if(u!=null){
							if(iCfg.getMethodOf(u)!=null)
							    logger.info("Caller Method: {}",iCfg.getMethodOf(u));
							level++;
							
							for(Unit u2 : iCfg.getSuccsOf(u)){
								if(u2!=null){
									if(TravelCFGForRelease(u2,level)==true)
										return true;
								}
							}
						}
					}
				}
			}
		}
		for(Unit cu : iCfg.getSuccsOf(source)){
			if(TravelCFGForRelease(cu,level)==true)
				return true;
		}
		if(!callStack.empty())
			callStack.pop();
		level--;
		return false;
	}

	private List<Unit> getTriggerCalls(Unit selectedChange){
		List<Unit> list = new ArrayList<Unit>();
		for(Unit call : mapCallToChanges.keySet()){
			if(mapCallToChanges.get(call).contains(selectedChange)){
				list.add(call);
			}
		}
		return list;
	}
	
	private Map<SootField, callChangePath> fieldPaths = new HashMap<SootField,callChangePath>();
	
	private void findUnguaranteedSaveErrors(){
		List<SootField> guaranteedFields = new ArrayList<SootField>();
		for(SootField sf : selectedFields){
			Map<callChangePath,AndroidMethod> changeStoreCallbacks = new HashMap<callChangePath,AndroidMethod>();
			for(callChangePath cp : changeStoreCallPaths){
				
				if(changeFields.get(cp.change).contains(sf)){
						if (cp.path != null && !cp.path.isEmpty()) {
								boolean gotCallback = false;
								List<Stmt> path = cp.path;
								int index = path.size()-1;
								Unit p;
								while (index>=0) {                   //get callbacks of the sinks
									p = path.get(index);						
									for(Entry<String,Set<AndroidMethod>> mEntry : Test.app.callbackMethods.entrySet()){
										for(AndroidMethod am : mEntry.getValue()){
											//logger.info("am: {}, icfg: {}", am, iCfg.getMethodOf(p));
											if(am.getMethodName().equals(iCfg.getMethodOf(p).getName())){
												if(am.toString().contains("onSaveInstanceState")||am.toString().contains("onPause")||am.toString().contains("onStop")||am.toString().contains("onDestroy"))
												    changeStoreCallbacks.put(cp,am);
												gotCallback = true;
												if(am.toString().contains("onPause")||am.toString().contains("onStop")){
													guaranteedFields.add(sf);
												}
												break;									
											}
										}
										if(gotCallback)
											break;
									}
									if(gotCallback)
										break;
									index = index-1;
								}
						}
				}
			}
			
		}

	}
	
	private int parent=0;
	private boolean isInitialization(SootMethod sm){		
			
			parent++;
			
			if(sm.getName().equals("<clinit>")||sm.getName().equals("<init>")||sm.getName().equals("onCreate")||sm.getName().equals("onStart")
					||sm.getName().startsWith("access$")){
				return true;
			}
			if(iCfg.getCallersOf(sm).isEmpty())
				return false;
			for(Unit u : iCfg.getCallersOf(sm)){
				if(u!=null){
					if(isInitialization(iCfg.getMethodOf(u))==false)
						return false;
				}
			}
			return true;
	}
	
	private void printCallbacksFromApi(SootField field){
		Stack<AndroidMethod> callbacks = new Stack<AndroidMethod>();
		for(Unit change : fieldChanges.get(field)){
		    for(callChangePath ccp : apiCallChangePaths){      //print callbacks from apiCall to change
		    	if(ccp.change.equals(change)){
		    		callbacks.clear();
		    		for(Stmt st : ccp.path){
		    			boolean isCallback = false;
		    			for(Entry<String,Set<AndroidMethod>> mEntry : Test.app.callbackMethods.entrySet()){
							for(AndroidMethod am : mEntry.getValue()){
								if(am.getMethodName().equals(iCfg.getMethodOf((Unit)st).getName())){
									if(callbacks.isEmpty()||!callbacks.peek().equals(am))
										callbacks.push(am);
									isCallback = true;
									break;									
								}
							}
							if(isCallback)
								break;
		    			}
		    		}
		    		if(!callbacks.isEmpty()){                        //print callbacks from apiCall to change
				    	for(AndroidMethod am : callbacks){
				    		logger.info("callback: {}, class: {}",am, am.getClassName());
				    	}
				    }
		    	}
		    }
		}
	}
	
	
	
	@Override
	public void computeInfoflow(String appPath, String libPath,
			IEntryPointCreator entryPointCreator,
			ISourceSinkManager sourcesSinks) {
		if (sourcesSinks == null) {
			logger.error("Sources are empty!");
			return;
		}
		
		Set<String> requiredClasses = SootMethodRepresentationParser.v().parseClassNames
				(entryPointCreator.getRequiredClasses(), false).keySet();
		initializeSoot(appPath, libPath, requiredClasses);

		// entryPoints are the entryPoints required by Soot to calculate Graph - if there is no main method,
		// we have to create a new main method and use it as entryPoint and store our real entryPoints
		Scene.v().setEntryPoints(Collections.singletonList(entryPointCreator.createDummyMain()));
		ipcManager.updateJimpleForICC();
		
		// We explicitly select the packs we want to run for performance reasons
		if (callgraphAlgorithm != CallgraphAlgorithm.OnDemand) {
	        PackManager.v().getPack("wjpp").apply();
	        PackManager.v().getPack("cg").apply();
		}
        
		aname=appPath;
		
	    if (callgraphAlgorithm != CallgraphAlgorithm.OnDemand)
	        logger.info("Callgraph has {} edges", Scene.v().getCallGraph().size());
	    iCfg = icfgFactory.buildBiDirICFG(callgraphAlgorithm);
	    
		for (SootMethod sm : getMethodsForSeeds(iCfg)){
	        scanMethodForApi(sm);
		}
		//System.exit(0);	
	    
	        
		for (SootMethod sm : getMethodsForSeeds(iCfg)){
			scanMethodForApiExitField(sm);
		}
		for (SootMethod sm : getMethodsForSeeds(iCfg)){
			scanMethodForAliasChanges(sm);
		}

		
		fields.addAll(fieldChanges.keySet());
		
		
		
		((AndroidSourceSinkManager)sourcesSinks).sourceMethods.clear();
		((AndroidSourceSinkManager)sourcesSinks).sinkMethods.clear();
		selectedChanges.clear();
		selectedFields.clear();
		selectedChanges_restore.clear();
		selectedChanges_api.clear();
		
		for(Unit source : changes){     //trace from changes to storeCalls thus we can select changes into selectedChanges.
			parent = 0;
			AndroidSourceSinkManager.dynamicSinks.clear();
			AndroidSourceSinkManager.dynamicSinks.addAll(storeCalls);
			AndroidSourceSinkManager.dynamicSources.clear();
			AndroidSourceSinkManager.dynamicSources.add(source);
			logger.info("Trace change: {}",source);
			runAnalysis_store(sourcesSinks,source,null);
		}

		for(Unit source : restoreCalls){   //trace from restoreCalls to changes into selectedChanges_restore
		    AndroidSourceSinkManager.dynamicSinks.clear();
		    boolean store = false;
		    for(Unit change:changes){
		    	for(SootField sootf : changeFields.get(change)){
			        if(selectedFields.contains(sootf)){
			            store=true;
			            break;
			        }
		    	}
		    	if(!store)
		    		AndroidSourceSinkManager.dynamicSinks.add(change);
		    }
		    AndroidSourceSinkManager.dynamicSources.clear();
		    AndroidSourceSinkManager.dynamicSources.add(source);
		    logger.info("Trace restoreCall {}",source);
		    runAnalysis_restore(sourcesSinks,source,null);
	    }
		
		
		findUnguaranteedSaveErrors();
		
		AndroidSourceSinkManager.dynamicSinks.clear();
		AndroidSourceSinkManager.dynamicSinks.addAll(exits);
		
		for(Unit source : changes){                      //explore control flow from selectedChanges to Exits
			if(((Stmt)source).containsFieldRef())
				logger.info("Tracing exits for change: {} in method: {}, class: {}, field: {}, line: {}",
					source,iCfg.getMethodOf(source),iCfg.getMethodOf(source).getDeclaringClass(),((Stmt)source).getFieldRef().getField(),source.getJavaSourceStartLineNumber());
			else
				continue;
			for(Unit call : getTriggerCalls(source)){
				logger.error("Trigger calls: {}, in method: {}, in class: {}", call, iCfg.getMethodOf(call), iCfg.getMethodOf(call).getDeclaringClass());
			}
				execPath = new Stack<Unit>();
				level = 0;
				boolean result = TravelCFGForChange(source,1);
				String fieldName = ((Stmt)source).getFieldRef().getField().getName();
				String methodName = iCfg.getMethodOf(source).getName();
				
				}
		   	    
		
		
		for(SootField field : fields){			
			if (KR1Fields1.contains(field)||KR1Fields2.contains(field))
				continue;
			if(selectedFields.contains(field)){
				for(Unit ch : fieldChanges.get(field))
					if(unsavedChanges.contains(ch)){
                                                if(hasField||max==0)
						KR2Fields.add(field);
						break;
					}
			}else{
				if(!selectedFields_restore.contains(field)){
					if(hasField)
					  KR3Fields.add(field);
				}else{
                                       if(hasField||max==0)
					KR4Fields.add(field); //guaranteed loss
                                }
			}
		}
		
		if (logger.isDebugEnabled())
			PackManager.v().writeOutput();
	}

        String aname;
	@Override
	public void computeInfoflow(String appPath, String libPath, String entryPoint,
			ISourceSinkManager sourcesSinks) {
		if (sourcesSinks == null) {
			logger.error("Sources are empty!");
			return;
		}

		initializeSoot(appPath, libPath,
				SootMethodRepresentationParser.v().parseClassNames
					(Collections.singletonList(entryPoint), false).keySet(), entryPoint);

		if (!Scene.v().containsMethod(entryPoint)){
			logger.error("Entry point not found: " + entryPoint);
			return;
		}
		SootMethod ep = Scene.v().getMethod(entryPoint);
		if (ep.isConcrete())
			ep.retrieveActiveBody();
		else {
			logger.debug("Skipping non-concrete method " + ep);
			return;
		}
		Scene.v().setEntryPoints(Collections.singletonList(ep));
		Options.v().set_main_class(ep.getDeclaringClass().getName());
		
		// Compute the additional seeds if they are specified
		Set<String> seeds = Collections.emptySet();
		if (entryPoint != null && !entryPoint.isEmpty())
			seeds = Collections.singleton(entryPoint);

		ipcManager.updateJimpleForICC();
		// We explicitly select the packs we want to run for performance reasons
		if (callgraphAlgorithm != CallgraphAlgorithm.OnDemand) {
	        PackManager.v().getPack("wjpp").apply();
	        PackManager.v().getPack("cg").apply();
		}
        runAnalysis(sourcesSinks, null, seeds);
		if (logger.isDebugEnabled())
			PackManager.v().writeOutput();
	}

	private void runAnalysis(final ISourceSinkManager sourcesSinks, Unit source, final Set<String> additionalSeeds) {
		// Run the preprocessors
        for (Transform tr : preProcessors)
            tr.apply();
        
        int numThreads = Runtime.getRuntime().availableProcessors();
		CountingThreadPoolExecutor executor = createExecutor(numThreads);
		
		BackwardsInfoflowProblem backProblem;
		InfoflowSolver backSolver;
		final IAliasingStrategy aliasingStrategy;
		switch (aliasingAlgorithm) {
			case FlowSensitive:
				backProblem = new BackwardsInfoflowProblem(new BackwardsInfoflowCFG(iCfg), sourcesSinks);
				// need to set this before creating the zero abstraction
				backProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
				
				backSolver = new InfoflowSolver(backProblem, executor);
				backSolver.setJumpPredecessors(!computeResultPaths);
				
				aliasingStrategy = new FlowSensitiveAliasStrategy(iCfg, backSolver);
				break;
			case PtsBased:
				backProblem = null;
				backSolver = null;
				aliasingStrategy = new PtsBasedAliasStrategy(iCfg);
				break;
			default:
				throw new RuntimeException("Unsupported aliasing algorithm");
		}
		
		InfoflowProblem forwardProblem  = new InfoflowProblem(iCfg, sourcesSinks,
				aliasingStrategy);
		// need to set this before creating the zero abstraction
		forwardProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
		if (backProblem != null)
			forwardProblem.setZeroValue(backProblem.createZeroValue());
		
		// Set the options
		InfoflowSolver forwardSolver = new InfoflowSolver(forwardProblem, executor);
		aliasingStrategy.setForwardSolver(forwardSolver);
		//forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardProblem.setInspectSources(inspectSources);
		forwardProblem.setInspectSinks(inspectSinks);
		forwardProblem.setEnableImplicitFlows(enableImplicitFlows);
		forwardProblem.setEnableStaticFieldTracking(enableStaticFields);
		forwardProblem.setEnableExceptionTracking(enableExceptions);
		for (TaintPropagationHandler tp : taintPropagationHandlers)
			forwardProblem.addTaintPropagationHandler(tp);
		forwardProblem.setTaintWrapper(taintWrapper);
		forwardProblem.setStopAfterFirstFlow(stopAfterFirstFlow);
		forwardProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		if (backProblem != null) {
			backProblem.setForwardSolver((InfoflowSolver) forwardSolver);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setEnableStaticFieldTracking(enableStaticFields);
			backProblem.setEnableExceptionTracking(enableExceptions);
			for (TaintPropagationHandler tp : taintPropagationHandlers)
				backProblem.addTaintPropagationHandler(tp);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setActivationUnitsToCallSites(forwardProblem);
			backProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
			backProblem.setInspectSources(inspectSources);
			backProblem.setInspectSinks(inspectSinks);
		}
		
		if (!enableStaticFields)
			logger.warn("Static field tracking is disabled, results may be incomplete");
		if (!flowSensitiveAliasing || !aliasingStrategy.isFlowSensitive())
			logger.warn("Using flow-insensitive alias tracking, results may be imprecise");

		// We have to look through the complete program to find sources
		// which are then taken as seeds.
		sinkCount = 0;
        logger.info("Looking for sources and sinks...");
        

        forwardProblem.addInitialSeeds(source, Collections.singleton(forwardProblem.zeroValue()));
		sinkCount = AndroidSourceSinkManager.dynamicSinks.size();
		
		// We optionally also allow additional seeds to be specified
		if (additionalSeeds != null)
			for (String meth : additionalSeeds) {
				SootMethod m = Scene.v().getMethod(meth);
				if (!m.hasActiveBody()) {
					logger.warn("Seed method {} has no active body", m);
					continue;
				}
				forwardProblem.addInitialSeeds(m.getActiveBody().getUnits().getFirst(),
						Collections.singleton(forwardProblem.zeroValue()));
			}
		
		if (!forwardProblem.hasInitialSeeds() || sinkCount == 0){
			logger.error("No sources or sinks found, aborting analysis");
			return;
		}

		logger.info("Source lookup done, found {} sources and {} sinks.", forwardProblem.getInitialSeeds().size(),
				sinkCount);
		
		forwardSolver.solve();
		
		// Not really nice, but sometimes Heros returns before all
		// executor tasks are actually done. This way, we give it a
		// chance to terminate gracefully before moving on.
		int terminateTries = 0;
		while (terminateTries < 10) {
			if (executor.getActiveCount() != 0 || !executor.isTerminated()) {
				terminateTries++;
				try {
					Thread.sleep(500);
				}
				catch (InterruptedException e) {
					logger.error("Could not wait for executor termination", e);
				}
			}
			else
				break;
		}
		if (executor.getActiveCount() != 0 || !executor.isTerminated())
			logger.error("Executor did not terminate gracefully");

		// Print taint wrapper statistics
		if (taintWrapper != null) {
			logger.info("Taint wrapper hits: " + taintWrapper.getWrapperHits());
			logger.info("Taint wrapper misses: " + taintWrapper.getWrapperMisses());
		}
		
		Set<AbstractionAtSink> res = forwardProblem.getResults();

		logger.debug("IFDS problem with {} forward and {} backward edges solved, "
				+ "processing {} results...", forwardSolver.propagationCount,
				backSolver == null ? 0 : backSolver.propagationCount,
				res == null ? 0 : res.size());
		
		// Force a cleanup. Everything we need is reachable through the
		// results set, the other abstractions can be killed now.
		forwardSolver.cleanup();
		if (backSolver != null) {
			backSolver.cleanup();
			backSolver = null;
			backProblem = null;
		}
		forwardSolver = null;
		forwardProblem = null;
		AccessPath.clearBaseRegister();
		Runtime.getRuntime().gc(); 
		//RuntimeUtil.gc();
		
		computeTaintPaths(res);

		
		if (results.getResults().isEmpty())
			logger.warn("No results found.");
		else{
			Set<Unit> set = new HashSet<Unit>();
			for(SinkInfo sinkInfo: results.getResults().keySet()){
				Unit change = (Unit)sinkInfo.getContext();
				if(iCfg.isFallThroughSuccessor(source, change))
					if((source instanceof AssignStmt))          
						if(((AssignStmt)source).getLeftOp().equals(((AssignStmt)change).getRightOp())){
							logger.info("Fake change: source={}, change={}",source,change);
							continue;
						}
				selectedChanges.add(change);
				changes.remove(change);
				set.add(change);
				logger.info("selectedChange: {}",change);
			}
			mapCallToChanges.put(source, set);
		}
			
	}

	private void runAnalysis_store(final ISourceSinkManager sourcesSinks, Unit source, final Set<String> additionalSeeds) {
		// Run the preprocessors
        for (Transform tr : preProcessors)
            tr.apply();
        
        int numThreads = Runtime.getRuntime().availableProcessors();
		CountingThreadPoolExecutor executor = createExecutor(numThreads);
		
		BackwardsInfoflowProblem backProblem;
		InfoflowSolver backSolver;
		final IAliasingStrategy aliasingStrategy;
		switch (aliasingAlgorithm) {
			case FlowSensitive:
				backProblem = new BackwardsInfoflowProblem(new BackwardsInfoflowCFG(iCfg), sourcesSinks);
				// need to set this before creating the zero abstraction
				backProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
				
				backSolver = new InfoflowSolver(backProblem, executor);
				backSolver.setJumpPredecessors(!computeResultPaths);
				
				aliasingStrategy = new FlowSensitiveAliasStrategy(iCfg, backSolver);
				break;
			case PtsBased:
				backProblem = null;
				backSolver = null;
				aliasingStrategy = new PtsBasedAliasStrategy(iCfg);
				break;
			default:
				throw new RuntimeException("Unsupported aliasing algorithm");
		}
		
		InfoflowProblem forwardProblem  = new InfoflowProblem(iCfg, sourcesSinks,
				aliasingStrategy);
		// need to set this before creating the zero abstraction
		forwardProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
		if (backProblem != null)
			forwardProblem.setZeroValue(backProblem.createZeroValue());
		
		// Set the options
		InfoflowSolver forwardSolver = new InfoflowSolver(forwardProblem, executor);
		aliasingStrategy.setForwardSolver(forwardSolver);
		//forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardProblem.setInspectSources(inspectSources);
		forwardProblem.setInspectSinks(inspectSinks);
		forwardProblem.setEnableImplicitFlows(enableImplicitFlows);
		forwardProblem.setEnableStaticFieldTracking(enableStaticFields);
		forwardProblem.setEnableExceptionTracking(enableExceptions);
		for (TaintPropagationHandler tp : taintPropagationHandlers)
			forwardProblem.addTaintPropagationHandler(tp);
		forwardProblem.setTaintWrapper(taintWrapper);
		forwardProblem.setStopAfterFirstFlow(stopAfterFirstFlow);
		forwardProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		if (backProblem != null) {
			backProblem.setForwardSolver((InfoflowSolver) forwardSolver);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setEnableStaticFieldTracking(enableStaticFields);
			backProblem.setEnableExceptionTracking(enableExceptions);
			for (TaintPropagationHandler tp : taintPropagationHandlers)
				backProblem.addTaintPropagationHandler(tp);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setActivationUnitsToCallSites(forwardProblem);
			backProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
			backProblem.setInspectSources(inspectSources);
			backProblem.setInspectSinks(inspectSinks);
		}
		
		if (!enableStaticFields)
			logger.warn("Static field tracking is disabled, results may be incomplete");
		if (!flowSensitiveAliasing || !aliasingStrategy.isFlowSensitive())
			logger.warn("Using flow-insensitive alias tracking, results may be imprecise");

		// We have to look through the complete program to find sources
		// which are then taken as seeds.
		sinkCount = 0;
        logger.info("Looking for sources and sinks...");
        
        forwardProblem.addInitialSeeds(source, Collections.singleton(forwardProblem.zeroValue()));
		sinkCount = AndroidSourceSinkManager.dynamicSinks.size();
		
		// We optionally also allow additional seeds to be specified
		if (additionalSeeds != null)
			for (String meth : additionalSeeds) {
				SootMethod m = Scene.v().getMethod(meth);
				if (!m.hasActiveBody()) {
					logger.warn("Seed method {} has no active body", m);
					continue;
				}
				forwardProblem.addInitialSeeds(m.getActiveBody().getUnits().getFirst(),
						Collections.singleton(forwardProblem.zeroValue()));
			}
		
		if (!forwardProblem.hasInitialSeeds() || sinkCount == 0){
			logger.error("No sources or sinks found, aborting analysis");
			return;
		}
		

		logger.info("Source lookup done, found {} sources and {} sinks.", forwardProblem.getInitialSeeds().size(),sinkCount);
		
		forwardSolver.solve();
		
		// Not really nice, but sometimes Heros returns before all
		// executor tasks are actually done. This way, we give it a
		// chance to terminate gracefully before moving on.
		int terminateTries = 0;
		while (terminateTries < 10) {
			if (executor.getActiveCount() != 0 || !executor.isTerminated()) {
				terminateTries++;
				try {
					Thread.sleep(500);
				}
				catch (InterruptedException e) {
					logger.error("Could not wait for executor termination", e);
				}
			}
			else
				break;
		}
		if (executor.getActiveCount() != 0 || !executor.isTerminated())
			logger.error("Executor did not terminate gracefully");

		// Print taint wrapper statistics
		if (taintWrapper != null) {
			logger.info("Taint wrapper hits: " + taintWrapper.getWrapperHits());
			logger.info("Taint wrapper misses: " + taintWrapper.getWrapperMisses());
		}
		
		Set<AbstractionAtSink> res = forwardProblem.getResults();

		logger.debug("IFDS problem with {} forward and {} backward edges solved, "
				+ "processing {} results...", forwardSolver.propagationCount,
				backSolver == null ? 0 : backSolver.propagationCount,
				res == null ? 0 : res.size());
		
		// Force a cleanup. Everything we need is reachable through the
		// results set, the other abstractions can be killed now.
		forwardSolver.cleanup();
		if (backSolver != null) {
			backSolver.cleanup();
			backSolver = null;
			backProblem = null;
		}
		forwardSolver = null;
		forwardProblem = null;
		AccessPath.clearBaseRegister();
		Runtime.getRuntime().gc(); 
		//RuntimeUtil.gc();
		
		computeTaintPaths(res);

		
		if (results.getResults().isEmpty())
			logger.warn("No storeCalls found.");
		else{
			selectedChanges.add(source);
			selectedFields.addAll(changeFields.get(source));
			for(SinkInfo sinkInfo: results.getResults().keySet()){
				Unit storeCall = (Unit)sinkInfo.getContext();
				logger.info("Found storeCall: {}",storeCall);
			}
			Set<Unit> set = new HashSet<Unit>();
			for (Entry<SinkInfo, Set<SourceInfo>> entry : results.getResults().entrySet()) {
				Unit storeCall = (Unit)entry.getKey().getContext();
				set.add(storeCall);
				for(SourceInfo si : entry.getValue()){
					changeStoreCallPaths.add(new callChangePath(storeCall,(Unit)si.getContext(),si.getPath()));
				}
			}
			mapChangeToStoreCalls.put(source, set);
		}
			
	}
	
	private void runAnalysis10(final ISourceSinkManager sourcesSinks, Unit source, final Set<String> additionalSeeds) {
		// Run the preprocessors
        for (Transform tr : preProcessors)
            tr.apply();
        
        int numThreads = Runtime.getRuntime().availableProcessors();
		CountingThreadPoolExecutor executor = createExecutor(numThreads);
		
		BackwardsInfoflowProblem backProblem;
		InfoflowSolver backSolver;
		final IAliasingStrategy aliasingStrategy;
		switch (aliasingAlgorithm) {
			case FlowSensitive:
				backProblem = new BackwardsInfoflowProblem(new BackwardsInfoflowCFG(iCfg), sourcesSinks);
				// need to set this before creating the zero abstraction
				backProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
				
				backSolver = new InfoflowSolver(backProblem, executor);
				backSolver.setJumpPredecessors(!computeResultPaths);
				
				aliasingStrategy = new FlowSensitiveAliasStrategy(iCfg, backSolver);
				break;
			case PtsBased:
				backProblem = null;
				backSolver = null;
				aliasingStrategy = new PtsBasedAliasStrategy(iCfg);
				break;
			default:
				throw new RuntimeException("Unsupported aliasing algorithm");
		}
		
		InfoflowProblem forwardProblem  = new InfoflowProblem(iCfg, sourcesSinks,
				aliasingStrategy);
		// need to set this before creating the zero abstraction
		forwardProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
		if (backProblem != null)
			forwardProblem.setZeroValue(backProblem.createZeroValue());
		
		// Set the options
		InfoflowSolver forwardSolver = new InfoflowSolver(forwardProblem, executor);
		aliasingStrategy.setForwardSolver(forwardSolver);
		//forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardProblem.setInspectSources(inspectSources);
		forwardProblem.setInspectSinks(inspectSinks);
		forwardProblem.setEnableImplicitFlows(enableImplicitFlows);
		forwardProblem.setEnableStaticFieldTracking(enableStaticFields);
		forwardProblem.setEnableExceptionTracking(enableExceptions);
		for (TaintPropagationHandler tp : taintPropagationHandlers)
			forwardProblem.addTaintPropagationHandler(tp);
		forwardProblem.setTaintWrapper(taintWrapper);
		forwardProblem.setStopAfterFirstFlow(stopAfterFirstFlow);
		forwardProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		if (backProblem != null) {
			backProblem.setForwardSolver((InfoflowSolver) forwardSolver);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setEnableStaticFieldTracking(enableStaticFields);
			backProblem.setEnableExceptionTracking(enableExceptions);
			for (TaintPropagationHandler tp : taintPropagationHandlers)
				backProblem.addTaintPropagationHandler(tp);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setActivationUnitsToCallSites(forwardProblem);
			backProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
			backProblem.setInspectSources(inspectSources);
			backProblem.setInspectSinks(inspectSinks);
		}
		
		if (!enableStaticFields)
			logger.warn("Static field tracking is disabled, results may be incomplete");
		if (!flowSensitiveAliasing || !aliasingStrategy.isFlowSensitive())
			logger.warn("Using flow-insensitive alias tracking, results may be imprecise");

		// We have to look through the complete program to find sources
		// which are then taken as seeds.
		sinkCount = 0;
        logger.info("Looking for sources and sinks...");
        
        forwardProblem.addInitialSeeds(source, Collections.singleton(forwardProblem.zeroValue()));
		sinkCount = AndroidSourceSinkManager.dynamicSinks.size();
		
		// We optionally also allow additional seeds to be specified
		if (additionalSeeds != null)
			for (String meth : additionalSeeds) {
				SootMethod m = Scene.v().getMethod(meth);
				if (!m.hasActiveBody()) {
					logger.warn("Seed method {} has no active body", m);
					continue;
				}
				forwardProblem.addInitialSeeds(m.getActiveBody().getUnits().getFirst(),
						Collections.singleton(forwardProblem.zeroValue()));
			}
		
		if (!forwardProblem.hasInitialSeeds() || sinkCount == 0){
			logger.error("No sources or sinks found, aborting analysis");
			return;
		}

		logger.info("Source lookup done, found {} sources and {} sinks.", forwardProblem.getInitialSeeds().size(),sinkCount);
		
		forwardSolver.solve();
		
		// Not really nice, but sometimes Heros returns before all
		// executor tasks are actually done. This way, we give it a
		// chance to terminate gracefully before moving on.
		int terminateTries = 0;
		while (terminateTries < 10) {
			if (executor.getActiveCount() != 0 || !executor.isTerminated()) {
				terminateTries++;
				try {
					Thread.sleep(500);
				}
				catch (InterruptedException e) {
					logger.error("Could not wait for executor termination", e);
				}
			}
			else
				break;
		}
		if (executor.getActiveCount() != 0 || !executor.isTerminated())
			logger.error("Executor did not terminate gracefully");

		// Print taint wrapper statistics
		if (taintWrapper != null) {
			logger.info("Taint wrapper hits: " + taintWrapper.getWrapperHits());
			logger.info("Taint wrapper misses: " + taintWrapper.getWrapperMisses());
		}
		
		Set<AbstractionAtSink> res = forwardProblem.getResults();

		logger.debug("IFDS problem with {} forward and {} backward edges solved, "
				+ "processing {} results...", forwardSolver.propagationCount,
				backSolver == null ? 0 : backSolver.propagationCount,
				res == null ? 0 : res.size());
		
		// Force a cleanup. Everything we need is reachable through the
		// results set, the other abstractions can be killed now.
		forwardSolver.cleanup();
		if (backSolver != null) {
			backSolver.cleanup();
			backSolver = null;
			backProblem = null;
		}
		forwardSolver = null;
		forwardProblem = null;
		AccessPath.clearBaseRegister();
		Runtime.getRuntime().gc(); 
		//RuntimeUtil.gc();
		
		computeTaintPaths(res);

		
		if (results.getResults().isEmpty())
			for(Unit call : mapCallToChanges.keySet()){
				if(mapCallToChanges.get(call).contains(source)){
					logger.warn("Found a restart bug: No storeCall for restoreCall: {}.",call);		
				}
			}
		else{
			Map<SinkInfo,AndroidMethod> sinkCallbacks = new HashMap<SinkInfo,AndroidMethod>();
			for (Entry<SinkInfo, Set<SourceInfo>> entry : results.getResults().entrySet()) {
				for (SourceInfo restoreCallInfo : entry.getValue()) {				
					if (restoreCallInfo.getPath() != null && !restoreCallInfo.getPath().isEmpty()) {
						boolean gotCallback = false;
						List<Stmt> path = restoreCallInfo.getPath();
						int index = path.size()-1;
						Unit p;
						while (index>=0) {                   //get callbacks of the sinks
							p = path.get(index);						
							for(Entry<String,Set<AndroidMethod>> mEntry : Test.app.callbackMethods.entrySet()){
								for(AndroidMethod am : mEntry.getValue()){
									if(am.getMethodName().equals("<clinit>"))
										continue;
									if(am.getMethodName().equals(iCfg.getMethodOf(p).getName())){
										sinkCallbacks.put(entry.getKey(),am);
										gotCallback = true;
										break;									
									}
								}
								if(gotCallback)
									break;
							}
							if(gotCallback){
								break;
							}
							index = index-1;
						}
					}
				}
			}
		}		
	}
	
	private void runAnalysis11(final ISourceSinkManager sourcesSinks, Unit source, final Set<String> additionalSeeds) {
		// Run the preprocessors
        for (Transform tr : preProcessors)
            tr.apply();
        
        int numThreads = Runtime.getRuntime().availableProcessors();
		CountingThreadPoolExecutor executor = createExecutor(numThreads);
		
		BackwardsInfoflowProblem backProblem;
		InfoflowSolver backSolver;
		final IAliasingStrategy aliasingStrategy;
		switch (aliasingAlgorithm) {
			case FlowSensitive:
				backProblem = new BackwardsInfoflowProblem(new BackwardsInfoflowCFG(iCfg), sourcesSinks);
				// need to set this before creating the zero abstraction
				backProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
				
				backSolver = new InfoflowSolver(backProblem, executor);
				backSolver.setJumpPredecessors(!computeResultPaths);
				
				aliasingStrategy = new FlowSensitiveAliasStrategy(iCfg, backSolver);
				break;
			case PtsBased:
				backProblem = null;
				backSolver = null;
				aliasingStrategy = new PtsBasedAliasStrategy(iCfg);
				break;
			default:
				throw new RuntimeException("Unsupported aliasing algorithm");
		}
		
		InfoflowProblem forwardProblem  = new InfoflowProblem(iCfg, sourcesSinks,
				aliasingStrategy);
		// need to set this before creating the zero abstraction
		forwardProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
		if (backProblem != null)
			forwardProblem.setZeroValue(backProblem.createZeroValue());
		
		// Set the options
		InfoflowSolver forwardSolver = new InfoflowSolver(forwardProblem, executor);
		aliasingStrategy.setForwardSolver(forwardSolver);
		//forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardProblem.setInspectSources(inspectSources);
		forwardProblem.setInspectSinks(inspectSinks);
		forwardProblem.setEnableImplicitFlows(enableImplicitFlows);
		forwardProblem.setEnableStaticFieldTracking(enableStaticFields);
		forwardProblem.setEnableExceptionTracking(enableExceptions);
		for (TaintPropagationHandler tp : taintPropagationHandlers)
			forwardProblem.addTaintPropagationHandler(tp);
		forwardProblem.setTaintWrapper(taintWrapper);
		forwardProblem.setStopAfterFirstFlow(stopAfterFirstFlow);
		forwardProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		if (backProblem != null) {
			backProblem.setForwardSolver((InfoflowSolver) forwardSolver);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setEnableStaticFieldTracking(enableStaticFields);
			backProblem.setEnableExceptionTracking(enableExceptions);
			for (TaintPropagationHandler tp : taintPropagationHandlers)
				backProblem.addTaintPropagationHandler(tp);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setActivationUnitsToCallSites(forwardProblem);
			backProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
			backProblem.setInspectSources(inspectSources);
			backProblem.setInspectSinks(inspectSinks);
		}
		
		if (!enableStaticFields)
			logger.warn("Static field tracking is disabled, results may be incomplete");
		if (!flowSensitiveAliasing || !aliasingStrategy.isFlowSensitive())
			logger.warn("Using flow-insensitive alias tracking, results may be imprecise");

		// We have to look through the complete program to find sources
		// which are then taken as seeds.
		sinkCount = 0;
        logger.info("Looking for sources and sinks...");
        
        forwardProblem.addInitialSeeds(source, Collections.singleton(forwardProblem.zeroValue()));
		sinkCount = AndroidSourceSinkManager.dynamicSinks.size();
		
		// We optionally also allow additional seeds to be specified
		if (additionalSeeds != null)
			for (String meth : additionalSeeds) {
				SootMethod m = Scene.v().getMethod(meth);
				if (!m.hasActiveBody()) {
					logger.warn("Seed method {} has no active body", m);
					continue;
				}
				forwardProblem.addInitialSeeds(m.getActiveBody().getUnits().getFirst(),
						Collections.singleton(forwardProblem.zeroValue()));
			}
		
		if (!forwardProblem.hasInitialSeeds() || sinkCount == 0){
			logger.error("No sources or sinks found, aborting analysis");
			return;
		}

		logger.info("Source lookup done, found {} sources and {} sinks.", forwardProblem.getInitialSeeds().size(),
				sinkCount);
		
		forwardSolver.solve();
		
		// Not really nice, but sometimes Heros returns before all
		// executor tasks are actually done. This way, we give it a
		// chance to terminate gracefully before moving on.
		int terminateTries = 0;
		while (terminateTries < 10) {
			if (executor.getActiveCount() != 0 || !executor.isTerminated()) {
				terminateTries++;
				try {
					Thread.sleep(500);
				}
				catch (InterruptedException e) {
					logger.error("Could not wait for executor termination", e);
				}
			}
			else
				break;
		}
		if (executor.getActiveCount() != 0 || !executor.isTerminated())
			logger.error("Executor did not terminate gracefully");

		// Print taint wrapper statistics
		if (taintWrapper != null) {
			logger.info("Taint wrapper hits: " + taintWrapper.getWrapperHits());
			logger.info("Taint wrapper misses: " + taintWrapper.getWrapperMisses());
		}
		
		Set<AbstractionAtSink> res = forwardProblem.getResults();

		logger.debug("IFDS problem with {} forward and {} backward edges solved, "
				+ "processing {} results...", forwardSolver.propagationCount,
				backSolver == null ? 0 : backSolver.propagationCount,
				res == null ? 0 : res.size());
		
		// Force a cleanup. Everything we need is reachable through the
		// results set, the other abstractions can be killed now.
		forwardSolver.cleanup();
		if (backSolver != null) {
			backSolver.cleanup();
			backSolver = null;
			backProblem = null;
		}
		forwardSolver = null;
		forwardProblem = null;
		AccessPath.clearBaseRegister();
		Runtime.getRuntime().gc(); 
		//RuntimeUtil.gc();
		
		computeTaintPaths(res);

		
		if (results.getResults().isEmpty())
			logger.warn("No results found.");
		else{
			Set<Unit> set = new HashSet<Unit>();
			for (Entry<SinkInfo, Set<SourceInfo>> entry : results.getResults().entrySet()) {
				Unit change = (Unit)entry.getKey().getContext();
				if(iCfg.isFallThroughSuccessor(source, change))
					if((source instanceof AssignStmt))          
						if(((AssignStmt)source).getLeftOp().equals(((AssignStmt)change).getRightOp())){
							logger.info("Fake change: source={}, change={}",source,change);
							continue;
						}
				selectedChanges_api.add(change);
				//changes.remove(change);
				set.add(change);
				logger.info("selectedChange_api: {}",change);
				for(SourceInfo si : entry.getValue()){
					callChangePaths.add(new callChangePath((Unit)si.getContext(),change,si.getPath()));
				}
			}
			mapCallToChanges.put(source, set);
		}
	}

	private void runAnalysis_api(final ISourceSinkManager sourcesSinks, Unit source, final Set<String> additionalSeeds) {
		// Run the preprocessors
        for (Transform tr : preProcessors)
            tr.apply();
        
        int numThreads = Runtime.getRuntime().availableProcessors();
		CountingThreadPoolExecutor executor = createExecutor(numThreads);
		
		BackwardsInfoflowProblem backProblem;
		InfoflowSolver backSolver;
		final IAliasingStrategy aliasingStrategy;
		switch (aliasingAlgorithm) {
			case FlowSensitive:
				backProblem = new BackwardsInfoflowProblem(new BackwardsInfoflowCFG(iCfg), sourcesSinks);
				// need to set this before creating the zero abstraction
				backProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
				
				backSolver = new InfoflowSolver(backProblem, executor);
				backSolver.setJumpPredecessors(!computeResultPaths);
//				backSolver.setEnableMergePointChecking(true);
				
				aliasingStrategy = new FlowSensitiveAliasStrategy(iCfg, backSolver);
				break;
			case PtsBased:
				backProblem = null;
				backSolver = null;
				aliasingStrategy = new PtsBasedAliasStrategy(iCfg);
				break;
			default:
				throw new RuntimeException("Unsupported aliasing algorithm");
		}
		
		InfoflowProblem forwardProblem  = new InfoflowProblem(iCfg, sourcesSinks,
				aliasingStrategy);
		// need to set this before creating the zero abstraction
		forwardProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
		if (backProblem != null)
			forwardProblem.setZeroValue(backProblem.createZeroValue());
		
		// Set the options
		InfoflowSolver forwardSolver = new InfoflowSolver(forwardProblem, executor);
		aliasingStrategy.setForwardSolver(forwardSolver);
		//forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardProblem.setInspectSources(inspectSources);
		forwardProblem.setInspectSinks(inspectSinks);
		forwardProblem.setEnableImplicitFlows(enableImplicitFlows);
		forwardProblem.setEnableStaticFieldTracking(enableStaticFields);
		forwardProblem.setEnableExceptionTracking(enableExceptions);
		for (TaintPropagationHandler tp : taintPropagationHandlers)
			forwardProblem.addTaintPropagationHandler(tp);
		forwardProblem.setTaintWrapper(taintWrapper);
		forwardProblem.setStopAfterFirstFlow(stopAfterFirstFlow);
		forwardProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		if (backProblem != null) {
			backProblem.setForwardSolver((InfoflowSolver) forwardSolver);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setEnableStaticFieldTracking(enableStaticFields);
			backProblem.setEnableExceptionTracking(enableExceptions);
			for (TaintPropagationHandler tp : taintPropagationHandlers)
				backProblem.addTaintPropagationHandler(tp);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setActivationUnitsToCallSites(forwardProblem);
			backProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
			backProblem.setInspectSources(inspectSources);
			backProblem.setInspectSinks(inspectSinks);
		}
		
		if (!enableStaticFields)
			logger.warn("Static field tracking is disabled, results may be incomplete");
		if (!flowSensitiveAliasing || !aliasingStrategy.isFlowSensitive())
			logger.warn("Using flow-insensitive alias tracking, results may be imprecise");

		// We have to look through the complete program to find sources
		// which are then taken as seeds.
		sinkCount = 0;
        logger.info("Looking for sources and sinks...");
        
        forwardProblem.addInitialSeeds(source, Collections.singleton(forwardProblem.zeroValue()));
		sinkCount = AndroidSourceSinkManager.dynamicSinks.size();
		
		// We optionally also allow additional seeds to be specified
		if (additionalSeeds != null)
			for (String meth : additionalSeeds) {
				SootMethod m = Scene.v().getMethod(meth);
				if (!m.hasActiveBody()) {
					logger.warn("Seed method {} has no active body", m);
					continue;
				}
				forwardProblem.addInitialSeeds(m.getActiveBody().getUnits().getFirst(),
						Collections.singleton(forwardProblem.zeroValue()));
			}
		
		if (!forwardProblem.hasInitialSeeds() || sinkCount == 0){
			logger.error("No sources or sinks found, aborting analysis");
			return;
		}

		logger.info("Source lookup done, found {} sources and {} sinks.", forwardProblem.getInitialSeeds().size(),
				sinkCount);
		
		forwardSolver.solve();
		
		// Not really nice, but sometimes Heros returns before all
		// executor tasks are actually done. This way, we give it a
		// chance to terminate gracefully before moving on.
		int terminateTries = 0;
		while (terminateTries < 10) {
			if (executor.getActiveCount() != 0 || !executor.isTerminated()) {
				terminateTries++;
				try {
					Thread.sleep(500);
				}
				catch (InterruptedException e) {
					logger.error("Could not wait for executor termination", e);
				}
			}
			else
				break;
		}
		if (executor.getActiveCount() != 0 || !executor.isTerminated())
			logger.error("Executor did not terminate gracefully");

		// Print taint wrapper statistics
		if (taintWrapper != null) {
			logger.info("Taint wrapper hits: " + taintWrapper.getWrapperHits());
			logger.info("Taint wrapper misses: " + taintWrapper.getWrapperMisses());
		}
		
		Set<AbstractionAtSink> res = forwardProblem.getResults();

		logger.debug("IFDS problem with {} forward and {} backward edges solved, "
				+ "processing {} results...", forwardSolver.propagationCount,
				backSolver == null ? 0 : backSolver.propagationCount,
				res == null ? 0 : res.size());
		
		// Force a cleanup. Everything we need is reachable through the
		// results set, the other abstractions can be killed now.
		forwardSolver.cleanup();
		if (backSolver != null) {
			backSolver.cleanup();
			backSolver = null;
			backProblem = null;
		}
		forwardSolver = null;
		forwardProblem = null;
		AccessPath.clearBaseRegister();
		Runtime.getRuntime().gc(); 
		//RuntimeUtil.gc();
		
		computeTaintPaths(res);

		
		if (results.getResults().isEmpty())
			logger.warn("No results found.");
		else{
			Set<Unit> set = new HashSet<Unit>();
			for (Entry<SinkInfo, Set<SourceInfo>> entry : results.getResults().entrySet()) {
				Unit change = (Unit)entry.getKey().getContext();
				
				selectedChanges_api.add(change);
				//changes.remove(change);
				set.add(change);
				logger.info("selectedChange_api: {}",change);
				for(SourceInfo si : entry.getValue()){
					apiCallChangePaths.add(new callChangePath((Unit)si.getContext(),change,si.getPath()));
				}
			}
			mapApiCallToChanges.put(source, set);
		}
	}

	
	private void runAnalysis_restore(final ISourceSinkManager sourcesSinks, Unit source, final Set<String> additionalSeeds) {
		// Run the preprocessors
        for (Transform tr : preProcessors)
            tr.apply();
        
        int numThreads = Runtime.getRuntime().availableProcessors();
		CountingThreadPoolExecutor executor = createExecutor(numThreads);
		
		BackwardsInfoflowProblem backProblem;
		InfoflowSolver backSolver;
		final IAliasingStrategy aliasingStrategy;
		switch (aliasingAlgorithm) {
			case FlowSensitive:
				backProblem = new BackwardsInfoflowProblem(new BackwardsInfoflowCFG(iCfg), sourcesSinks);
				// need to set this before creating the zero abstraction
				backProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
				
				backSolver = new InfoflowSolver(backProblem, executor);
				backSolver.setJumpPredecessors(!computeResultPaths);
//				backSolver.setEnableMergePointChecking(true);
				
				aliasingStrategy = new FlowSensitiveAliasStrategy(iCfg, backSolver);
				break;
			case PtsBased:
				backProblem = null;
				backSolver = null;
				aliasingStrategy = new PtsBasedAliasStrategy(iCfg);
				break;
			default:
				throw new RuntimeException("Unsupported aliasing algorithm");
		}
		
		InfoflowProblem forwardProblem  = new InfoflowProblem(iCfg, sourcesSinks,
				aliasingStrategy);
		// need to set this before creating the zero abstraction
		forwardProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
		if (backProblem != null)
			forwardProblem.setZeroValue(backProblem.createZeroValue());
		
		// Set the options
		InfoflowSolver forwardSolver = new InfoflowSolver(forwardProblem, executor);
		aliasingStrategy.setForwardSolver(forwardSolver);
		//forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardProblem.setInspectSources(inspectSources);
		forwardProblem.setInspectSinks(inspectSinks);
		forwardProblem.setEnableImplicitFlows(enableImplicitFlows);
		forwardProblem.setEnableStaticFieldTracking(enableStaticFields);
		forwardProblem.setEnableExceptionTracking(enableExceptions);
		for (TaintPropagationHandler tp : taintPropagationHandlers)
			forwardProblem.addTaintPropagationHandler(tp);
		forwardProblem.setTaintWrapper(taintWrapper);
		forwardProblem.setStopAfterFirstFlow(stopAfterFirstFlow);
		forwardProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		if (backProblem != null) {
			backProblem.setForwardSolver((InfoflowSolver) forwardSolver);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setEnableStaticFieldTracking(enableStaticFields);
			backProblem.setEnableExceptionTracking(enableExceptions);
			for (TaintPropagationHandler tp : taintPropagationHandlers)
				backProblem.addTaintPropagationHandler(tp);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setActivationUnitsToCallSites(forwardProblem);
			backProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
			backProblem.setInspectSources(inspectSources);
			backProblem.setInspectSinks(inspectSinks);
		}
		
		if (!enableStaticFields)
			logger.warn("Static field tracking is disabled, results may be incomplete");
		if (!flowSensitiveAliasing || !aliasingStrategy.isFlowSensitive())
			logger.warn("Using flow-insensitive alias tracking, results may be imprecise");

		// We have to look through the complete program to find sources
		// which are then taken as seeds.
		sinkCount = 0;
        logger.info("Looking for sources and sinks...");
        
        forwardProblem.addInitialSeeds(source, Collections.singleton(forwardProblem.zeroValue()));
		sinkCount = AndroidSourceSinkManager.dynamicSinks.size();
		
		// We optionally also allow additional seeds to be specified
		if (additionalSeeds != null)
			for (String meth : additionalSeeds) {
				SootMethod m = Scene.v().getMethod(meth);
				if (!m.hasActiveBody()) {
					logger.warn("Seed method {} has no active body", m);
					continue;
				}
				forwardProblem.addInitialSeeds(m.getActiveBody().getUnits().getFirst(),
						Collections.singleton(forwardProblem.zeroValue()));
			}
		
		if (!forwardProblem.hasInitialSeeds() || sinkCount == 0){
			logger.error("No sources or sinks found, aborting analysis");
			return;
		}
		

		logger.info("Source lookup done, found {} sources and {} sinks.", forwardProblem.getInitialSeeds().size(),
				sinkCount);
		
		forwardSolver.solve();
		
		// Not really nice, but sometimes Heros returns before all
		// executor tasks are actually done. This way, we give it a
		// chance to terminate gracefully before moving on.
		int terminateTries = 0;
		while (terminateTries < 10) {
			if (executor.getActiveCount() != 0 || !executor.isTerminated()) {
				terminateTries++;
				try {
					Thread.sleep(500);
				}
				catch (InterruptedException e) {
					logger.error("Could not wait for executor termination", e);
				}
			}
			else
				break;
		}
		if (executor.getActiveCount() != 0 || !executor.isTerminated())
			logger.error("Executor did not terminate gracefully");

		// Print taint wrapper statistics
		if (taintWrapper != null) {
			logger.info("Taint wrapper hits: " + taintWrapper.getWrapperHits());
			logger.info("Taint wrapper misses: " + taintWrapper.getWrapperMisses());
		}
		
		Set<AbstractionAtSink> res = forwardProblem.getResults();

		logger.debug("IFDS problem with {} forward and {} backward edges solved, "
				+ "processing {} results...", forwardSolver.propagationCount,
				backSolver == null ? 0 : backSolver.propagationCount,
				res == null ? 0 : res.size());
		
		// Force a cleanup. Everything we need is reachable through the
		// results set, the other abstractions can be killed now.
		forwardSolver.cleanup();
		if (backSolver != null) {
			backSolver.cleanup();
			backSolver = null;
			backProblem = null;
		}
		forwardSolver = null;
		forwardProblem = null;
		AccessPath.clearBaseRegister();
		Runtime.getRuntime().gc(); 
		//RuntimeUtil.gc();
		
		computeTaintPaths(res);

		
		if (results.getResults().isEmpty())
			logger.warn("No results found.");
		else{
			for (Entry<SinkInfo, Set<SourceInfo>> entry : results.getResults().entrySet()) {
				Unit change = (Unit)entry.getKey().getContext();
				if(iCfg.isFallThroughSuccessor(source, change))
					if((source instanceof AssignStmt))          
						if(((AssignStmt)source).getLeftOp().equals(((AssignStmt)change).getRightOp())){
							logger.info("Fake change: source={}, change={}",source,change);
							continue;
						}
				selectedChanges_restore.add(change);
				selectedFields_restore.addAll(changeFields.get(change));
				for(SourceInfo si : entry.getValue()){
					callChangePaths.add(new callChangePath((Unit)si.getContext(),change,si.getPath()));
				}
			}
			//mapCallToChanges.put(source, set);
		}
	}

	private void runAnalysis8(final ISourceSinkManager sourcesSinks, Unit source, final Set<String> additionalSeeds) {
		// Run the preprocessors
        for (Transform tr : preProcessors)
            tr.apply();
        
        int numThreads = Runtime.getRuntime().availableProcessors();
		CountingThreadPoolExecutor executor = createExecutor(numThreads);
		
		BackwardsInfoflowProblem backProblem;
		InfoflowSolver backSolver;
		final IAliasingStrategy aliasingStrategy;
		switch (aliasingAlgorithm) {
			case FlowSensitive:
				backProblem = new BackwardsInfoflowProblem(new BackwardsInfoflowCFG(iCfg), sourcesSinks);
				// need to set this before creating the zero abstraction
				backProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
				
				backSolver = new InfoflowSolver(backProblem, executor);
				backSolver.setJumpPredecessors(!computeResultPaths);
//				backSolver.setEnableMergePointChecking(true);
				
				aliasingStrategy = new FlowSensitiveAliasStrategy(iCfg, backSolver);
				break;
			case PtsBased:
				backProblem = null;
				backSolver = null;
				aliasingStrategy = new PtsBasedAliasStrategy(iCfg);
				break;
			default:
				throw new RuntimeException("Unsupported aliasing algorithm");
		}
		
		InfoflowProblem forwardProblem  = new InfoflowProblem(iCfg, sourcesSinks,
				aliasingStrategy);
		// need to set this before creating the zero abstraction
		forwardProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
		if (backProblem != null)
			forwardProblem.setZeroValue(backProblem.createZeroValue());
		
		// Set the options
		InfoflowSolver forwardSolver = new InfoflowSolver(forwardProblem, executor);
		aliasingStrategy.setForwardSolver(forwardSolver);
		//forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardProblem.setInspectSources(inspectSources);
		forwardProblem.setInspectSinks(inspectSinks);
		forwardProblem.setEnableImplicitFlows(enableImplicitFlows);
		forwardProblem.setEnableStaticFieldTracking(enableStaticFields);
		forwardProblem.setEnableExceptionTracking(enableExceptions);
		for (TaintPropagationHandler tp : taintPropagationHandlers)
			forwardProblem.addTaintPropagationHandler(tp);
		forwardProblem.setTaintWrapper(taintWrapper);
		forwardProblem.setStopAfterFirstFlow(stopAfterFirstFlow);
		forwardProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		if (backProblem != null) {
			backProblem.setForwardSolver((InfoflowSolver) forwardSolver);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setEnableStaticFieldTracking(enableStaticFields);
			backProblem.setEnableExceptionTracking(enableExceptions);
			for (TaintPropagationHandler tp : taintPropagationHandlers)
				backProblem.addTaintPropagationHandler(tp);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setActivationUnitsToCallSites(forwardProblem);
			backProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
			backProblem.setInspectSources(inspectSources);
			backProblem.setInspectSinks(inspectSinks);
		}
		
		if (!enableStaticFields)
			logger.warn("Static field tracking is disabled, results may be incomplete");
		if (!flowSensitiveAliasing || !aliasingStrategy.isFlowSensitive())
			logger.warn("Using flow-insensitive alias tracking, results may be imprecise");

		// We have to look through the complete program to find sources
		// which are then taken as seeds.
		sinkCount = 0;
        logger.info("Looking for sources and sinks...");
        
        forwardProblem.addInitialSeeds(source, Collections.singleton(forwardProblem.zeroValue()));
		sinkCount = AndroidSourceSinkManager.dynamicSinks.size();
		
		// We optionally also allow additional seeds to be specified
		if (additionalSeeds != null)
			for (String meth : additionalSeeds) {
				SootMethod m = Scene.v().getMethod(meth);
				if (!m.hasActiveBody()) {
					logger.warn("Seed method {} has no active body", m);
					continue;
				}
				forwardProblem.addInitialSeeds(m.getActiveBody().getUnits().getFirst(),
						Collections.singleton(forwardProblem.zeroValue()));
			}
		
		if (!forwardProblem.hasInitialSeeds() || sinkCount == 0){
			logger.error("No sources or sinks found, aborting analysis");
			return;
		}

		logger.info("Source lookup done, found {} sources and {} sinks.", forwardProblem.getInitialSeeds().size(),
				sinkCount);
		
		forwardSolver.solve();
		
		// Not really nice, but sometimes Heros returns before all
		// executor tasks are actually done. This way, we give it a
		// chance to terminate gracefully before moving on.
		int terminateTries = 0;
		while (terminateTries < 10) {
			if (executor.getActiveCount() != 0 || !executor.isTerminated()) {
				terminateTries++;
				try {
					Thread.sleep(500);
				}
				catch (InterruptedException e) {
					logger.error("Could not wait for executor termination", e);
				}
			}
			else
				break;
		}
		if (executor.getActiveCount() != 0 || !executor.isTerminated())
			logger.error("Executor did not terminate gracefully");

		// Print taint wrapper statistics
		if (taintWrapper != null) {
			logger.info("Taint wrapper hits: " + taintWrapper.getWrapperHits());
			logger.info("Taint wrapper misses: " + taintWrapper.getWrapperMisses());
		}
		
		Set<AbstractionAtSink> res = forwardProblem.getResults();

		logger.debug("IFDS problem with {} forward and {} backward edges solved, "
				+ "processing {} results...", forwardSolver.propagationCount,
				backSolver == null ? 0 : backSolver.propagationCount,
				res == null ? 0 : res.size());
		
		// Force a cleanup. Everything we need is reachable through the
		// results set, the other abstractions can be killed now.
		forwardSolver.cleanup();
		if (backSolver != null) {
			backSolver.cleanup();
			backSolver = null;
			backProblem = null;
		}
		forwardSolver = null;
		forwardProblem = null;
		AccessPath.clearBaseRegister();
		Runtime.getRuntime().gc(); 
		//RuntimeUtil.gc();
		
		computeTaintPaths(res);

		
		if (results.getResults().isEmpty())
			logger.warn("No storeCall found.");
		else{
			for(SinkInfo sinkInfo: results.getResults().keySet()){
				Unit storeCall = (Unit)sinkInfo.getContext();
				logger.info("storeCall: {}",storeCall);
			}
		}
			
	}

	private void runAnalysis5(final ISourceSinkManager sourcesSinks, Unit source, final Set<String> additionalSeeds) {
		// Run the preprocessors
        for (Transform tr : preProcessors)
            tr.apply();
        
        int numThreads = Runtime.getRuntime().availableProcessors();
		CountingThreadPoolExecutor executor = createExecutor(numThreads);
		
		BackwardsInfoflowProblem backProblem;
		InfoflowSolver backSolver;
		final IAliasingStrategy aliasingStrategy;
		switch (aliasingAlgorithm) {
			case FlowSensitive:
				backProblem = new BackwardsInfoflowProblem(new BackwardsInfoflowCFG(iCfg), sourcesSinks);
				// need to set this before creating the zero abstraction
				backProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
				
				backSolver = new InfoflowSolver(backProblem, executor);
				backSolver.setJumpPredecessors(!computeResultPaths);
//				backSolver.setEnableMergePointChecking(true);
				
				aliasingStrategy = new FlowSensitiveAliasStrategy(iCfg, backSolver);
				break;
			case PtsBased:
				backProblem = null;
				backSolver = null;
				aliasingStrategy = new PtsBasedAliasStrategy(iCfg);
				break;
			default:
				throw new RuntimeException("Unsupported aliasing algorithm");
		}
		
		InfoflowProblem forwardProblem  = new InfoflowProblem(iCfg, sourcesSinks,
				aliasingStrategy);
		// need to set this before creating the zero abstraction
		forwardProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
		if (backProblem != null)
			forwardProblem.setZeroValue(backProblem.createZeroValue());
		
		// Set the options
		InfoflowSolver forwardSolver = new InfoflowSolver(forwardProblem, executor);
		aliasingStrategy.setForwardSolver(forwardSolver);
		forwardSolver.setJumpPredecessors(!computeResultPaths);
//		forwardSolver.setEnableMergePointChecking(true);
		
		forwardProblem.setInspectSources(inspectSources);
		forwardProblem.setInspectSinks(inspectSinks);
		forwardProblem.setEnableImplicitFlows(enableImplicitFlows);
		forwardProblem.setEnableStaticFieldTracking(enableStaticFields);
		forwardProblem.setEnableExceptionTracking(enableExceptions);
		for (TaintPropagationHandler tp : taintPropagationHandlers)
			forwardProblem.addTaintPropagationHandler(tp);
		forwardProblem.setTaintWrapper(taintWrapper);
		forwardProblem.setStopAfterFirstFlow(stopAfterFirstFlow);
		forwardProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		if (backProblem != null) {
			backProblem.setForwardSolver((InfoflowSolver) forwardSolver);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setEnableStaticFieldTracking(enableStaticFields);
			backProblem.setEnableExceptionTracking(enableExceptions);
			for (TaintPropagationHandler tp : taintPropagationHandlers)
				backProblem.addTaintPropagationHandler(tp);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setActivationUnitsToCallSites(forwardProblem);
			backProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
			backProblem.setInspectSources(inspectSources);
			backProblem.setInspectSinks(inspectSinks);
		}
		
		if (!enableStaticFields)
			logger.warn("Static field tracking is disabled, results may be incomplete");
		if (!flowSensitiveAliasing || !aliasingStrategy.isFlowSensitive())
			logger.warn("Using flow-insensitive alias tracking, results may be imprecise");

		// We have to look through the complete program to find sources
		// which are then taken as seeds.
		sinkCount = 0;
        logger.info("Looking for sources and sinks...");
        
        forwardProblem.addInitialSeeds(source, Collections.singleton(forwardProblem.zeroValue()));
		sinkCount = AndroidSourceSinkManager.dynamicSinks.size();
		
		// We optionally also allow additional seeds to be specified
		if (additionalSeeds != null)
			for (String meth : additionalSeeds) {
				SootMethod m = Scene.v().getMethod(meth);
				if (!m.hasActiveBody()) {
					logger.warn("Seed method {} has no active body", m);
					continue;
				}
				forwardProblem.addInitialSeeds(m.getActiveBody().getUnits().getFirst(),
						Collections.singleton(forwardProblem.zeroValue()));
			}
		
		if (!forwardProblem.hasInitialSeeds() || sinkCount == 0){
			logger.error("No sources or sinks found, aborting analysis");
			return;
		}

		logger.info("Source lookup done, found {} sources and {} sinks.", forwardProblem.getInitialSeeds().size(),
				sinkCount);
		
		forwardSolver.solve();
		
		// Not really nice, but sometimes Heros returns before all
		// executor tasks are actually done. This way, we give it a
		// chance to terminate gracefully before moving on.
		int terminateTries = 0;
		while (terminateTries < 10) {
			if (executor.getActiveCount() != 0 || !executor.isTerminated()) {
				terminateTries++;
				try {
					Thread.sleep(500);
				}
				catch (InterruptedException e) {
					logger.error("Could not wait for executor termination", e);
				}
			}
			else
				break;
		}
		if (executor.getActiveCount() != 0 || !executor.isTerminated())
			logger.error("Executor did not terminate gracefully");

		// Print taint wrapper statistics
		if (taintWrapper != null) {
			logger.info("Taint wrapper hits: " + taintWrapper.getWrapperHits());
			logger.info("Taint wrapper misses: " + taintWrapper.getWrapperMisses());
		}
		
		Set<AbstractionAtSink> res = forwardProblem.getResults();

		logger.debug("IFDS problem with {} forward and {} backward edges solved, "
				+ "processing {} results...", forwardSolver.propagationCount,
				backSolver == null ? 0 : backSolver.propagationCount,
				res == null ? 0 : res.size());
		
		// Force a cleanup. Everything we need is reachable through the
		// results set, the other abstractions can be killed now.
		forwardSolver.cleanup();
		if (backSolver != null) {
			backSolver.cleanup();
			backSolver = null;
			backProblem = null;
		}
		forwardSolver = null;
		forwardProblem = null;
		AccessPath.clearBaseRegister();
		Runtime.getRuntime().gc(); 
		//RuntimeUtil.gc();
		
		computeTaintPaths(res);

	}
	
	private void runAnalysis4(final ISourceSinkManager sourcesSinks, Unit source, final Set<String> additionalSeeds) {
		// Run the preprocessors
        for (Transform tr : preProcessors)
            tr.apply();
        
        int numThreads = Runtime.getRuntime().availableProcessors();
		CountingThreadPoolExecutor executor = createExecutor(numThreads);
		
		BackwardsInfoflowProblem backProblem;
		InfoflowSolver backSolver;
		final IAliasingStrategy aliasingStrategy;
		switch (aliasingAlgorithm) {
			case FlowSensitive:
				backProblem = new BackwardsInfoflowProblem(new BackwardsInfoflowCFG(iCfg), sourcesSinks);
				// need to set this before creating the zero abstraction
				backProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
				
				backSolver = new InfoflowSolver(backProblem, executor);
				backSolver.setJumpPredecessors(!computeResultPaths);
//				backSolver.setEnableMergePointChecking(true);
				
				aliasingStrategy = new FlowSensitiveAliasStrategy(iCfg, backSolver);
				break;
			case PtsBased:
				backProblem = null;
				backSolver = null;
				aliasingStrategy = new PtsBasedAliasStrategy(iCfg);
				break;
			default:
				throw new RuntimeException("Unsupported aliasing algorithm");
		}
		
		InfoflowProblem forwardProblem  = new InfoflowProblem(iCfg, sourcesSinks,
				aliasingStrategy);
		// need to set this before creating the zero abstraction
		forwardProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
		if (backProblem != null)
			forwardProblem.setZeroValue(backProblem.createZeroValue());
		
		// Set the options
		InfoflowSolver forwardSolver = new InfoflowSolver(forwardProblem, executor);
		aliasingStrategy.setForwardSolver(forwardSolver);
		forwardSolver.setJumpPredecessors(!computeResultPaths);
//		forwardSolver.setEnableMergePointChecking(true);
		
		forwardProblem.setInspectSources(inspectSources);
		forwardProblem.setInspectSinks(inspectSinks);
		forwardProblem.setEnableImplicitFlows(enableImplicitFlows);
		forwardProblem.setEnableStaticFieldTracking(enableStaticFields);
		forwardProblem.setEnableExceptionTracking(enableExceptions);
		for (TaintPropagationHandler tp : taintPropagationHandlers)
			forwardProblem.addTaintPropagationHandler(tp);
		forwardProblem.setTaintWrapper(taintWrapper);
		forwardProblem.setStopAfterFirstFlow(stopAfterFirstFlow);
		forwardProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		if (backProblem != null) {
			backProblem.setForwardSolver((InfoflowSolver) forwardSolver);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setEnableStaticFieldTracking(enableStaticFields);
			backProblem.setEnableExceptionTracking(enableExceptions);
			for (TaintPropagationHandler tp : taintPropagationHandlers)
				backProblem.addTaintPropagationHandler(tp);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setActivationUnitsToCallSites(forwardProblem);
			backProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
			backProblem.setInspectSources(inspectSources);
			backProblem.setInspectSinks(inspectSinks);
		}
		
		if (!enableStaticFields)
			logger.warn("Static field tracking is disabled, results may be incomplete");
		if (!flowSensitiveAliasing || !aliasingStrategy.isFlowSensitive())
			logger.warn("Using flow-insensitive alias tracking, results may be imprecise");

		// We have to look through the complete program to find sources
		// which are then taken as seeds.
		sinkCount = 0;
        logger.info("Looking for sources and sinks...");
        
         forwardProblem.addInitialSeeds(source, Collections.singleton(forwardProblem.zeroValue()));
		sinkCount = AndroidSourceSinkManager.dynamicSinks.size();
		
		// We optionally also allow additional seeds to be specified
		if (additionalSeeds != null)
			for (String meth : additionalSeeds) {
				SootMethod m = Scene.v().getMethod(meth);
				if (!m.hasActiveBody()) {
					logger.warn("Seed method {} has no active body", m);
					continue;
				}
				forwardProblem.addInitialSeeds(m.getActiveBody().getUnits().getFirst(),
						Collections.singleton(forwardProblem.zeroValue()));
			}
		
		if (!forwardProblem.hasInitialSeeds() || sinkCount == 0){
			logger.error("No sources or sinks found, aborting analysis");
			return;
		}

		logger.info("Source lookup done, found {} sources and {} sinks.", forwardProblem.getInitialSeeds().size(),
				sinkCount);
		
		forwardSolver.solve();
		
		// Not really nice, but sometimes Heros returns before all
		// executor tasks are actually done. This way, we give it a
		// chance to terminate gracefully before moving on.
		int terminateTries = 0;
		while (terminateTries < 10) {
			if (executor.getActiveCount() != 0 || !executor.isTerminated()) {
				terminateTries++;
				try {
					Thread.sleep(500);
				}
				catch (InterruptedException e) {
					logger.error("Could not wait for executor termination", e);
				}
			}
			else
				break;
		}
		if (executor.getActiveCount() != 0 || !executor.isTerminated())
			logger.error("Executor did not terminate gracefully");

		// Print taint wrapper statistics
		if (taintWrapper != null) {
			logger.info("Taint wrapper hits: " + taintWrapper.getWrapperHits());
			logger.info("Taint wrapper misses: " + taintWrapper.getWrapperMisses());
		}
		
		Set<AbstractionAtSink> res = forwardProblem.getResults();

		logger.debug("IFDS problem with {} forward and {} backward edges solved, "
				+ "processing {} results...", forwardSolver.propagationCount,
				backSolver == null ? 0 : backSolver.propagationCount,
				res == null ? 0 : res.size());
		
		// Force a cleanup. Everything we need is reachable through the
		// results set, the other abstractions can be killed now.
		forwardSolver.cleanup();
		if (backSolver != null) {
			backSolver.cleanup();
			backSolver = null;
			backProblem = null;
		}
		forwardSolver = null;
		forwardProblem = null;
		AccessPath.clearBaseRegister();
		Runtime.getRuntime().gc();  
		//RuntimeUtil.gc();
		
		computeTaintPaths(res);

		
		if (results.getResults().isEmpty())
			logger.warn("No results found.");
		else{
			selectedChanges.add(source);
			//changes.remove(source);
			logger.info("selectedChange4: {}",source);
		}
	}

	private void runAnalysis6(final ISourceSinkManager sourcesSinks, Unit source, final Set<String> additionalSeeds) {
		// Run the preprocessors
        for (Transform tr : preProcessors)
            tr.apply();
        
        int numThreads = Runtime.getRuntime().availableProcessors();
		CountingThreadPoolExecutor executor = createExecutor(numThreads);
		
		BackwardsInfoflowProblem backProblem;
		InfoflowSolver backSolver;
		final IAliasingStrategy aliasingStrategy;
		switch (aliasingAlgorithm) {
			case FlowSensitive:
				backProblem = new BackwardsInfoflowProblem(new BackwardsInfoflowCFG(iCfg), sourcesSinks);
				// need to set this before creating the zero abstraction
				backProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
				
				backSolver = new InfoflowSolver(backProblem, executor);
				backSolver.setJumpPredecessors(!computeResultPaths);
				
				aliasingStrategy = new FlowSensitiveAliasStrategy(iCfg, backSolver);
				break;
			case PtsBased:
				backProblem = null;
				backSolver = null;
				aliasingStrategy = new PtsBasedAliasStrategy(iCfg);
				break;
			default:
				throw new RuntimeException("Unsupported aliasing algorithm");
		}
		
		InfoflowProblem forwardProblem  = new InfoflowProblem(iCfg, sourcesSinks,
				aliasingStrategy);
		// need to set this before creating the zero abstraction
		forwardProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
		if (backProblem != null)
			forwardProblem.setZeroValue(backProblem.createZeroValue());
		
		// Set the options
		InfoflowSolver forwardSolver = new InfoflowSolver(forwardProblem, executor);
		aliasingStrategy.setForwardSolver(forwardSolver);
		forwardSolver.setJumpPredecessors(!computeResultPaths);
//		forwardSolver.setEnableMergePointChecking(true);
		
		forwardProblem.setInspectSources(inspectSources);
		forwardProblem.setInspectSinks(inspectSinks);
		forwardProblem.setEnableImplicitFlows(enableImplicitFlows);
		forwardProblem.setEnableStaticFieldTracking(enableStaticFields);
		forwardProblem.setEnableExceptionTracking(enableExceptions);
		for (TaintPropagationHandler tp : taintPropagationHandlers)
			forwardProblem.addTaintPropagationHandler(tp);
		forwardProblem.setTaintWrapper(taintWrapper);
		forwardProblem.setStopAfterFirstFlow(stopAfterFirstFlow);
		forwardProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		if (backProblem != null) {
			backProblem.setForwardSolver((InfoflowSolver) forwardSolver);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setEnableStaticFieldTracking(enableStaticFields);
			backProblem.setEnableExceptionTracking(enableExceptions);
			for (TaintPropagationHandler tp : taintPropagationHandlers)
				backProblem.addTaintPropagationHandler(tp);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setActivationUnitsToCallSites(forwardProblem);
			backProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
			backProblem.setInspectSources(inspectSources);
			backProblem.setInspectSinks(inspectSinks);
		}
		
		if (!enableStaticFields)
			logger.warn("Static field tracking is disabled, results may be incomplete");
		if (!flowSensitiveAliasing || !aliasingStrategy.isFlowSensitive())
			logger.warn("Using flow-insensitive alias tracking, results may be imprecise");

		// We have to look through the complete program to find sources
		// which are then taken as seeds.
		sinkCount = 0;
        logger.info("Looking for sources and sinks...");
        
        forwardProblem.addInitialSeeds(source, Collections.singleton(forwardProblem.zeroValue()));
		sinkCount = AndroidSourceSinkManager.dynamicSinks.size();
		
		// We optionally also allow additional seeds to be specified
		if (additionalSeeds != null)
			for (String meth : additionalSeeds) {
				SootMethod m = Scene.v().getMethod(meth);
				if (!m.hasActiveBody()) {
					logger.warn("Seed method {} has no active body", m);
					continue;
				}
				forwardProblem.addInitialSeeds(m.getActiveBody().getUnits().getFirst(),
						Collections.singleton(forwardProblem.zeroValue()));
			}
		
		if (!forwardProblem.hasInitialSeeds() || sinkCount == 0){
			logger.error("No sources or sinks found, aborting analysis");
			return;
		}

		logger.info("Source lookup done, found {} sources and {} sinks.", forwardProblem.getInitialSeeds().size(),
				sinkCount);
		
		forwardSolver.solve();
		
		// Not really nice, but sometimes Heros returns before all
		// executor tasks are actually done. This way, we give it a
		// chance to terminate gracefully before moving on.
		int terminateTries = 0;
		while (terminateTries < 10) {
			if (executor.getActiveCount() != 0 || !executor.isTerminated()) {
				terminateTries++;
				try {
					Thread.sleep(500);
				}
				catch (InterruptedException e) {
					logger.error("Could not wait for executor termination", e);
				}
			}
			else
				break;
		}
		if (executor.getActiveCount() != 0 || !executor.isTerminated())
			logger.error("Executor did not terminate gracefully");

		// Print taint wrapper statistics
		if (taintWrapper != null) {
			logger.info("Taint wrapper hits: " + taintWrapper.getWrapperHits());
			logger.info("Taint wrapper misses: " + taintWrapper.getWrapperMisses());
		}
		
		Set<AbstractionAtSink> res = forwardProblem.getResults();

		logger.debug("IFDS problem with {} forward and {} backward edges solved, "
				+ "processing {} results...", forwardSolver.propagationCount,
				backSolver == null ? 0 : backSolver.propagationCount,
				res == null ? 0 : res.size());
		
		// Force a cleanup. Everything we need is reachable through the
		// results set, the other abstractions can be killed now.
		forwardSolver.cleanup();
		if (backSolver != null) {
			backSolver.cleanup();
			backSolver = null;
			backProblem = null;
		}
		forwardSolver = null;
		forwardProblem = null;
		AccessPath.clearBaseRegister();
		Runtime.getRuntime().gc();  
		//RuntimeUtil.gc();
		
		computeTaintPaths(res);

		
		SootMethod sourceMethod = iCfg.getMethodOf(source);
		Map<SinkInfo,AndroidMethod> sinkCallbacks = new HashMap<SinkInfo,AndroidMethod>();
		fieldSet.clear();
		localMap.clear();
		arraySet.clear();
		changeSet.clear();
		
		if (results.getResults().isEmpty()){
			logger.warn("No releasing call for {}", source);
		}else for (Entry<SinkInfo, Set<SourceInfo>> entry : results.getResults().entrySet()) {
			logger.info("Found a releasing call: {}", entry.getKey().getContext());
			for (SourceInfo si : entry.getValue()) {				
				if (si.getPath() != null && !si.getPath().isEmpty()) {
					boolean gotCallback = false;
					List<Stmt> path = si.getPath();
					int index = path.size()-1;
					Unit p;
					int i=0;
					for(Unit p1 : path){
						if(((Stmt)p1).containsFieldRef()){
							fieldSet.add(((Stmt)p1).getFieldRef().getField());  //record related fields
						}
						if(((Stmt)p1).containsArrayRef()){
							arraySet.add(((Stmt)p1).getArrayRef().getBase());  //record related arrays
						}
						if((p1 instanceof AssignStmt)){                        //record related locals
							if(((AssignStmt)p1).getLeftOp() instanceof Local){
								localMap.put((Local)((AssignStmt)p1).getLeftOp(),iCfg.getMethodOf(p1));	
							}
							if(((AssignStmt)p1).getRightOp() instanceof Local){
								localMap.put((Local)((AssignStmt)p1).getRightOp(),iCfg.getMethodOf(p1));	
							}
						}
						logger.debug("p{}={}",i,((Stmt)p1).toString());
						i++;
					}
					while (index>=0) {                   //get callbacks of the sinks
						p = path.get(index);						
						for(Entry<String,Set<AndroidMethod>> mEntry : Test.app.callbackMethods.entrySet()){
							for(AndroidMethod am : mEntry.getValue()){
								//logger.info("am: {}, icfg: {}", am, iCfg.getMethodOf(p));
								if(am.getMethodName().equals(iCfg.getMethodOf(p).getName())){
									logger.debug("callback: {}", iCfg.getMethodOf(p));  //??
									sinkCallbacks.put(entry.getKey(),am);
									gotCallback = true;
									break;									
								}
							}
							if(gotCallback)
								break;
						  //logger.info("callbackMethod: {}, {}, iCfgMethod: {}", mEntry.getKey(), mEntry.getValue(), iCfg.getMethodOf(p));
						}
						if(gotCallback){
							break;
						}
						index = index-1;
					}
					if(!gotCallback){
						logger.warn("No callback for the sink");
					}
				}
			}
		}
		if(!fieldSet.isEmpty()){
			logger.info("fieldSet: {}.  localSet: {}",fieldSet.toString(),localMap.toString());
		}
		
		//identify various types of errors.
		
		if(sinkCallbacks.size()==0){
			logger.info("unreleased error: acquiring call [{}] does not have releasing call.",source);
			return;
		}
		boolean hasOtherCallbacks = false;
		for(AndroidMethod callback : sinkCallbacks.values()){
			if(callback.toString().contains("onSaveInstanceState")){
				hasOtherCallbacks = false;
				for(AndroidMethod callback2 : sinkCallbacks.values()){
					if(!(callback2.toString().contains("onSaveInstanceState")||callback2.toString().contains("onDestroy"))){
						hasOtherCallbacks = true;
					}
				}
				if(!hasOtherCallbacks){
					logger.info("unguaranteed release error: [{}] only has releasing call in onSaveInstanceState().",sourceMethod);
					return;
				}
			}else if(callback.toString().contains("onDestroy")){
				hasOtherCallbacks = false;
				for(AndroidMethod callback2 : sinkCallbacks.values()){
					if(!(callback2.toString().contains("onSaveInstanceState")||callback2.toString().contains("onDestroy"))){
						hasOtherCallbacks = true;
					}
				}
				if(!hasOtherCallbacks){
					logger.info("unguaranteed save error: source [{}] only has sinks in onDestroy().",sourceMethod);
					return;
				}
			}else if(callback.toString().contains("onPause")||callback.toString().contains("onStop")){
				logger.info("guaranteed save: source [{}] has sinks in [{}].",sourceMethod,callback);
				return;	
			}else{
				if(!fieldSet.isEmpty()){
					//logger.info("fieldSet: {}",fieldSet.toString());
					for (SootMethod sm : getMethodsForSeeds(iCfg)){
						scanMethodForChanges(sm);
					}
				}
			}
		}
	}

	//  perform data-flow tracing for the second time
	private void runAnalysis2(final ISourceSinkManager sourcesSinks, final Set<String> additionalSeeds) {
		
		logger.info("Perform data-flow tracing for the second time...");
		// Run the preprocessors
        for (Transform tr : preProcessors)
            tr.apply();
        
        int numThreads = Runtime.getRuntime().availableProcessors();
		CountingThreadPoolExecutor executor = createExecutor(numThreads);
		
		BackwardsInfoflowProblem backProblem;
		InfoflowSolver backSolver;
		final IAliasingStrategy aliasingStrategy;
		switch (aliasingAlgorithm) {
			case FlowSensitive:
				backProblem = new BackwardsInfoflowProblem(new BackwardsInfoflowCFG(iCfg), sourcesSinks);
				// need to set this before creating the zero abstraction
				backProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
				
				backSolver = new InfoflowSolver(backProblem, executor);
				backSolver.setJumpPredecessors(!computeResultPaths);
				
				aliasingStrategy = new FlowSensitiveAliasStrategy(iCfg, backSolver);
				break;
			case PtsBased:
				backProblem = null;
				backSolver = null;
				aliasingStrategy = new PtsBasedAliasStrategy(iCfg);
				break;
			default:
				throw new RuntimeException("Unsupported aliasing algorithm");
		}
		
		InfoflowProblem forwardProblem  = new InfoflowProblem(iCfg, sourcesSinks, aliasingStrategy);
		// need to set this before creating the zero abstraction
		forwardProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
		if (backProblem != null)
			forwardProblem.setZeroValue(backProblem.createZeroValue());
		
		// Set the options
		InfoflowSolver forwardSolver = new InfoflowSolver(forwardProblem, executor);
		aliasingStrategy.setForwardSolver(forwardSolver);
		forwardSolver.setJumpPredecessors(!computeResultPaths);
		
		forwardProblem.setInspectSources(inspectSources);
		forwardProblem.setInspectSinks(inspectSinks);
		forwardProblem.setEnableImplicitFlows(enableImplicitFlows);
		forwardProblem.setEnableStaticFieldTracking(enableStaticFields);
		forwardProblem.setEnableExceptionTracking(enableExceptions);
		for (TaintPropagationHandler tp : taintPropagationHandlers)
			forwardProblem.addTaintPropagationHandler(tp);
		forwardProblem.setTaintWrapper(taintWrapper);
		forwardProblem.setStopAfterFirstFlow(true); 
		forwardProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		if (backProblem != null) {
			backProblem.setForwardSolver((InfoflowSolver) forwardSolver);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setEnableStaticFieldTracking(enableStaticFields);
			backProblem.setEnableExceptionTracking(enableExceptions);
			for (TaintPropagationHandler tp : taintPropagationHandlers)
				backProblem.addTaintPropagationHandler(tp);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setActivationUnitsToCallSites(forwardProblem);
			backProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
			backProblem.setInspectSources(inspectSources);
			backProblem.setInspectSinks(inspectSinks);
		}
		
		if (!enableStaticFields)
			logger.warn("Static field tracking is disabled, results may be incomplete");
		if (!flowSensitiveAliasing || !aliasingStrategy.isFlowSensitive())
			logger.warn("Using flow-insensitive alias tracking, results may be imprecise");

		// We have to look through the complete program to find sources
		// which are then taken as seeds.
		//int sinkCount = 0;
        logger.info("Looking for sources and sinks...");
        
        //for (SootMethod sm : getMethodsForSeeds(iCfg))
			//sinkCount += scanMethodForSourcesSinks(sourcesSinks, forwardProblem, sm);
        if(!changeSet.isEmpty()){
			for (Unit u : changeSet) {
				forwardProblem.addInitialSeeds(u, Collections.singleton(forwardProblem.zeroValue()));
			}
        }else{
        	logger.info("There is no unsaved change.");
        	return;
        }
			
		// We optionally also allow additional seeds to be specified
		if (additionalSeeds != null)
			for (String meth : additionalSeeds) {
				SootMethod m = Scene.v().getMethod(meth);
				if (!m.hasActiveBody()) {
					logger.warn("Seed method {} has no active body", m);
					continue;
				}
				forwardProblem.addInitialSeeds(m.getActiveBody().getUnits().getFirst(),
						Collections.singleton(forwardProblem.zeroValue()));
			}
		
		if (!forwardProblem.hasInitialSeeds() || sinkCount == 0){
			logger.error("No sources or sinks found, aborting analysis");
			return;
		}

		logger.info("Source lookup done, found {} sources and {} sinks.", forwardProblem.getInitialSeeds().size(), sinkCount);
		
		forwardSolver.solve();
		
		// Not really nice, but sometimes Heros returns before all
		// executor tasks are actually done. This way, we give it a
		// chance to terminate gracefully before moving on.
		int terminateTries = 0;
		while (terminateTries < 10) {
			if (executor.getActiveCount() != 0 || !executor.isTerminated()) {
				terminateTries++;
				try {
					Thread.sleep(500);
				}
				catch (InterruptedException e) {
					logger.error("Could not wait for executor termination", e);
				}
			}
			else
				break;
		}
		if (executor.getActiveCount() != 0 || !executor.isTerminated())
			logger.error("Executor did not terminate gracefully");

		// Print taint wrapper statistics
		if (taintWrapper != null) {
			logger.info("Taint wrapper hits: " + taintWrapper.getWrapperHits());
			logger.info("Taint wrapper misses: " + taintWrapper.getWrapperMisses());
		}
		
		Set<AbstractionAtSink> res = forwardProblem.getResults();

		logger.debug("IFDS problem with {} forward and {} backward edges solved, "
				+ "processing {} results...", forwardSolver.propagationCount,
				backSolver == null ? 0 : backSolver.propagationCount,
				res == null ? 0 : res.size());
		
		// Force a cleanup. Everything we need is reachable through the
		// results set, the other abstractions can be killed now.
		forwardSolver.cleanup();
		if (backSolver != null) {
			backSolver.cleanup();
			backSolver = null;
			backProblem = null;
		}
		forwardSolver = null;
		forwardProblem = null;
		AccessPath.clearBaseRegister();
		Runtime.getRuntime().gc();
		
		computeTaintPaths(res);
				
	}

	private void runAnalysis3(final ISourceSinkManager sourcesSinks, final Set<String> additionalSeeds) {
		// Run the preprocessors
        for (Transform tr : preProcessors)
            tr.apply();
        
        int numThreads = Runtime.getRuntime().availableProcessors();
		CountingThreadPoolExecutor executor = createExecutor(numThreads);
		
		BackwardsInfoflowProblem backProblem;
		InfoflowSolver backSolver;
		final IAliasingStrategy aliasingStrategy;
		switch (aliasingAlgorithm) {
			case FlowSensitive:
				backProblem = new BackwardsInfoflowProblem(new BackwardsInfoflowCFG(iCfg), sourcesSinks);
				// need to set this before creating the zero abstraction
				backProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
				
				backSolver = new InfoflowSolver(backProblem, executor);
				backSolver.setJumpPredecessors(!computeResultPaths);
				
				aliasingStrategy = new FlowSensitiveAliasStrategy(iCfg, backSolver);
				break;
			case PtsBased:
				backProblem = null;
				backSolver = null;
				aliasingStrategy = new PtsBasedAliasStrategy(iCfg);
				break;
			default:
				throw new RuntimeException("Unsupported aliasing algorithm");
		}
		
		InfoflowProblem forwardProblem  = new InfoflowProblem(iCfg, sourcesSinks,
				aliasingStrategy);
		// need to set this before creating the zero abstraction
		forwardProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
		if (backProblem != null)
			forwardProblem.setZeroValue(backProblem.createZeroValue());
		
		// Set the options
		InfoflowSolver forwardSolver = new InfoflowSolver(forwardProblem, executor);
		aliasingStrategy.setForwardSolver(forwardSolver);
		forwardSolver.setJumpPredecessors(!computeResultPaths);
//		forwardSolver.setEnableMergePointChecking(true);
		
		forwardProblem.setInspectSources(inspectSources);
		forwardProblem.setInspectSinks(inspectSinks);
		forwardProblem.setEnableImplicitFlows(enableImplicitFlows);
		forwardProblem.setEnableStaticFieldTracking(enableStaticFields);
		forwardProblem.setEnableExceptionTracking(enableExceptions);
		for (TaintPropagationHandler tp : taintPropagationHandlers)
			forwardProblem.addTaintPropagationHandler(tp);
		forwardProblem.setTaintWrapper(taintWrapper);
		forwardProblem.setStopAfterFirstFlow(stopAfterFirstFlow);
		forwardProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		if (backProblem != null) {
			backProblem.setForwardSolver((InfoflowSolver) forwardSolver);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setEnableStaticFieldTracking(enableStaticFields);
			backProblem.setEnableExceptionTracking(enableExceptions);
			for (TaintPropagationHandler tp : taintPropagationHandlers)
				backProblem.addTaintPropagationHandler(tp);
			backProblem.setTaintWrapper(taintWrapper);
			backProblem.setActivationUnitsToCallSites(forwardProblem);
			backProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
			backProblem.setInspectSources(inspectSources);
			backProblem.setInspectSinks(inspectSinks);
		}
		
		if (!enableStaticFields)
			logger.warn("Static field tracking is disabled, results may be incomplete");
		if (!flowSensitiveAliasing || !aliasingStrategy.isFlowSensitive())
			logger.warn("Using flow-insensitive alias tracking, results may be imprecise");

		// We have to look through the complete program to find sources
		// which are then taken as seeds.
		sinkCount = 0;
        logger.info("Looking for sources and sinks...");
        
        for (SootMethod sm : getMethodsForSeeds(iCfg))
			sinkCount += scanMethodForSourcesSinks(sourcesSinks, forwardProblem, sm);
        
		// We optionally also allow additional seeds to be specified
		if (additionalSeeds != null)
			for (String meth : additionalSeeds) {
				SootMethod m = Scene.v().getMethod(meth);
				if (!m.hasActiveBody()) {
					logger.warn("Seed method {} has no active body", m);
					continue;
				}
				forwardProblem.addInitialSeeds(m.getActiveBody().getUnits().getFirst(),
						Collections.singleton(forwardProblem.zeroValue()));
			}
		
		if (!forwardProblem.hasInitialSeeds() || sinkCount == 0){
			logger.error("No sources or sinks found, aborting analysis");
			return;
		}

		logger.info("Source lookup done, found {} sources and {} sinks.", forwardProblem.getInitialSeeds().size(),
				sinkCount);
		
		forwardSolver.solve();
		
		// Not really nice, but sometimes Heros returns before all
		// executor tasks are actually done. This way, we give it a
		// chance to terminate gracefully before moving on.
		int terminateTries = 0;
		while (terminateTries < 10) {
			if (executor.getActiveCount() != 0 || !executor.isTerminated()) {
				terminateTries++;
				try {
					Thread.sleep(500);
				}
				catch (InterruptedException e) {
					logger.error("Could not wait for executor termination", e);
				}
			}
			else
				break;
		}
		if (executor.getActiveCount() != 0 || !executor.isTerminated())
			logger.error("Executor did not terminate gracefully");

		// Print taint wrapper statistics
		if (taintWrapper != null) {
			logger.info("Taint wrapper hits: " + taintWrapper.getWrapperHits());
			logger.info("Taint wrapper misses: " + taintWrapper.getWrapperMisses());
		}
		
		Set<AbstractionAtSink> res = forwardProblem.getResults();

		logger.debug("IFDS problem with {} forward and {} backward edges solved, "
				+ "processing {} results...", forwardSolver.propagationCount,
				backSolver == null ? 0 : backSolver.propagationCount,
				res == null ? 0 : res.size());
		
		// Force a cleanup. Everything we need is reachable through the
		// results set, the other abstractions can be killed now.
		forwardSolver.cleanup();
		if (backSolver != null) {
			backSolver.cleanup();
			backSolver = null;
			backProblem = null;
		}
		forwardSolver = null;
		forwardProblem = null;
		AccessPath.clearBaseRegister();
		Runtime.getRuntime().gc();
		
		computeTaintPaths(res);

		
		AndroidMethod sourceMethod = ((AndroidSourceSinkManager)sourcesSinks).sourceMethods.values().toArray(new AndroidMethod[0])[0];
		Map<SinkInfo,AndroidMethod> sinkCallbacks = new HashMap<SinkInfo,AndroidMethod>();
		fieldSet.clear();
		localMap.clear();
		arraySet.clear();
		changeSet.clear();
		
		if (results.getResults().isEmpty()){
			logger.warn("No sink for {}", sourceMethod);
		}else for (Entry<SinkInfo, Set<SourceInfo>> entry : results.getResults().entrySet()) {
			logger.info("source: {} ==> sink: {}", sourceMethod, entry.getKey());
			for (SourceInfo source : entry.getValue()) {				
				if (source.getPath() != null && !source.getPath().isEmpty()) {
					boolean gotCallback = false;
					List<Stmt> path = source.getPath();
					int index = path.size()-1;
					Unit p;
					int i=0;
					for(Unit p1 : path){
						if(((Stmt)p1).containsFieldRef()){
							fieldSet.add(((Stmt)p1).getFieldRef().getField());  //record related fields
						}
						if(((Stmt)p1).containsArrayRef()){
							arraySet.add(((Stmt)p1).getArrayRef().getBase());  //record related arrays
						}
						if((p1 instanceof AssignStmt)){                        //record related locals
							if(((AssignStmt)p1).getLeftOp() instanceof Local){
								localMap.put((Local)((AssignStmt)p1).getLeftOp(),iCfg.getMethodOf(p1));	
							}
							if(((AssignStmt)p1).getRightOp() instanceof Local){
								localMap.put((Local)((AssignStmt)p1).getRightOp(),iCfg.getMethodOf(p1));	
							}
						}
						logger.debug("p{}={}",i,((Stmt)p1).toString());
						i++;
					}
					while (index>=0) {                   //get callbacks of the sinks
						p = path.get(index);						
						for(Entry<String,Set<AndroidMethod>> mEntry : Test.app.callbackMethods.entrySet()){
							for(AndroidMethod am : mEntry.getValue()){
								//logger.info("am: {}, icfg: {}", am, iCfg.getMethodOf(p));
								if(am.getMethodName().equals(iCfg.getMethodOf(p).getName())){
									logger.debug("callback: {}", iCfg.getMethodOf(p));  //??
									sinkCallbacks.put(entry.getKey(),am);
									gotCallback = true;
									break;									
								}
							}
							if(gotCallback)
								break;
						  //logger.info("callbackMethod: {}, {}, iCfgMethod: {}", mEntry.getKey(), mEntry.getValue(), iCfg.getMethodOf(p));
						}
						if(gotCallback){
							break;
						}
						index = index-1;
					}
					if(!gotCallback){
						logger.warn("No callback for the sink");
					}
				}
			}
		}
		if(!fieldSet.isEmpty()){
			logger.info("fieldSet: {}.  localSet: {}",fieldSet.toString(),localMap.toString());
		}
		
		//identify various types of errors.
		
		if(sinkCallbacks.size()==0){
			logger.info("unsaved error: source [{}] does not have sink.",sourceMethod);
			return;
		}
		boolean hasOtherCallbacks = false;
		for(AndroidMethod callback : sinkCallbacks.values()){
            if(callback.toString().contains("onDestroy")){
				hasOtherCallbacks = false;
				for(AndroidMethod callback2 : sinkCallbacks.values()){
					if(!(callback2.toString().contains("onSaveInstanceState")||callback2.toString().contains("onDestroy"))){
						hasOtherCallbacks = true;
					}
				}
				if(!hasOtherCallbacks){
					logger.info("unguaranteed save error: source [{}] only has sinks in onDestroy().",sourceMethod);
					return;
				}
			}else if(callback.toString().contains("onPause")||callback.toString().contains("onStop")){
				logger.info("guaranteed save: source [{}] has sinks in [{}].",sourceMethod,callback);
				return;	
			}else{
				if(!fieldSet.isEmpty()){
					//logger.info("fieldSet: {}",fieldSet.toString());
					for (SootMethod sm : getMethodsForSeeds(iCfg)){
						scanMethodForChanges(sm);
					}
				}
			}
		}
		
	}

	
	/**
	 * Creates a new executor object for spawning worker threads
	 * @param numThreads The number of threads to use
	 * @return The generated executor
	 */
	private CountingThreadPoolExecutor createExecutor(int numThreads) {
		return new CountingThreadPoolExecutor
				(maxThreadNum == -1 ? numThreads : Math.min(maxThreadNum, numThreads),
				Integer.MAX_VALUE, 30, TimeUnit.SECONDS,
				new LinkedBlockingQueue<Runnable>());
	}
	
	/**
	 * Computes the path of tainted data between the source and the sink
	 * @param res The data flow tracker results
	 */
	private void computeTaintPaths(final Set<AbstractionAtSink> res) {
		IAbstractionPathBuilder builder = this.pathBuilderFactory.createPathBuilder(maxThreadNum);
    	if (computeResultPaths)
    		builder.computeTaintPaths(res);
    	else
    		builder.computeTaintSources(res);
    	this.results = builder.getResults();
    	builder.shutdown();
	}

	private Collection<SootMethod> getMethodsForSeeds(IInfoflowCFG icfg) {
		List<SootMethod> seeds = new LinkedList<SootMethod>();
		// If we have a callgraph, we retrieve the reachable methods. Otherwise,
		// we have no choice but take all application methods as an approximation
		if (Scene.v().hasCallGraph()) {
			List<MethodOrMethodContext> eps = new ArrayList<MethodOrMethodContext>(Scene.v().getEntryPoints());
			ReachableMethods reachableMethods = new ReachableMethods(Scene.v().getCallGraph(), eps.iterator(), null);
			reachableMethods.update();
			for (Iterator<MethodOrMethodContext> iter = reachableMethods.listener(); iter.hasNext();)
				seeds.add(iter.next().method());
		}
		else {
			long beforeSeedMethods = System.nanoTime();
			Set<SootMethod> doneSet = new HashSet<SootMethod>();
			for (SootMethod sm : Scene.v().getEntryPoints())
				getMethodsForSeedsIncremental(sm, doneSet, seeds, icfg);
			logger.info("Collecting seed methods took {} seconds", (System.nanoTime() - beforeSeedMethods) / 1E9);
		}
		return seeds;
	}

	private void getMethodsForSeedsIncremental(SootMethod sm,
			Set<SootMethod> doneSet, List<SootMethod> seeds, IInfoflowCFG icfg) {
		assert Scene.v().hasFastHierarchy();
		if (!sm.isConcrete() || !sm.getDeclaringClass().isApplicationClass() || !doneSet.add(sm))
			return;
		seeds.add(sm);
		for (Unit u : sm.retrieveActiveBody().getUnits()) {
			Stmt stmt = (Stmt) u;
			if (stmt.containsInvokeExpr())
				for (SootMethod callee : icfg.getCalleesOfCallAt(stmt))
					getMethodsForSeedsIncremental(callee, doneSet, seeds, icfg);
		}
	}

	/**
	 * Scans the given method for sources and sinks contained in it. Sinks are
	 * just counted, sources are added to the InfoflowProblem as seeds.
	 * @param sourcesSinks The SourceSinkManager to be used for identifying
	 * sources and sinks
	 * @param forwardProblem The InfoflowProblem in which to register the
	 * sources as seeds
	 * @param m The method to scan for sources and sinks
	 * @return The number of sinks found in this method
	 */
	private int scanMethodForSourcesSinks(
			final ISourceSinkManager sourcesSinks,
			InfoflowProblem forwardProblem,
			SootMethod m) {
		int sinkCount = 0;
		if (m.hasActiveBody()) {
			// Check whether this is a system class we need to ignore
			final String className = m.getDeclaringClass().getName();
			if (ignoreFlowsInSystemPackages && SystemClassHandler.isClassInSystemPackage(className))
				return sinkCount;
			
			// Look for a source in the method. Also look for sinks. If we
			// have no sink in the program, we don't need to perform any
			// analysis
			PatchingChain<Unit> units = m.getActiveBody().getUnits();
			for (Unit u : units) {
				Stmt s = (Stmt) u;
				if (sourcesSinks.getSourceInfo(s, iCfg) != null) {
					forwardProblem.addInitialSeeds(u, Collections.singleton(forwardProblem.zeroValue()));
					logger.debug("Source found: {}", u);
				}
				if (sourcesSinks.isSink(s, iCfg)) {
		            logger.debug("Sink found: {}", u);
					sinkCount++;
				}
			}
			
		}
		return sinkCount;
	}

	private void scanMethodForChanges(SootMethod m) {
		if (m.hasActiveBody()) {
			// Check whether this is a system class we need to ignore
			final String className = m.getDeclaringClass().getName();
			boolean contain = false;
			if (ignoreFlowsInSystemPackages && SystemClassHandler.isClassInSystemPackage(className))
				return;
			
			// Look for changes in the method.
			PatchingChain<Unit> units = m.getActiveBody().getUnits();
			for (Unit u : units) {
				//if(((Stmt)p1).containsArrayRef()){        //check array in the future
					//arraySet.add(((Stmt)p1).getArrayRef().getBase());  
				//}
				if((u instanceof AssignStmt)){                        
					if(((AssignStmt)u).getLeftOp() instanceof Local){
						Local loc = (Local)((AssignStmt)u).getLeftOp();
						if(localMap.containsKey(loc)){
							if(localMap.get(loc).toString().equals(iCfg.getMethodOf(u).toString())){
								contain=false;
								for (Entry<SinkInfo, Set<SourceInfo>> entry : results.getResults().entrySet()) {
									for (SourceInfo source : entry.getValue()) {				
										if (source.getPath() != null && !source.getPath().isEmpty()) {
											List<Stmt> path = source.getPath();
											if(path.contains(u)){
												contain=true;
												break;
											}
										}
									}
									if(contain)
										break;
								}
								if(!contain){
									changeSet.add(u);
									logger.info("add-local-change: {}",u.toString());
								}
							}
						}
					}
					if(((AssignStmt)u).getLeftOp() instanceof FieldRef){
						SootField sf = ((FieldRef)((AssignStmt)u).getLeftOp()).getField();
						if(fieldSet.contains(sf)){
							contain=false;
							for (Entry<SinkInfo, Set<SourceInfo>> entry : results.getResults().entrySet()) {
								for (SourceInfo source : entry.getValue()) {				
									if (source.getPath() != null && !source.getPath().isEmpty()) {
										List<Stmt> path = source.getPath();
										if(path.contains(u)){
											contain=true;
											break;
										}
									}
								}
								if(contain)
									break;
							}
							if(!contain){
								changeSet.add(u);
								logger.info("add-field-change: {}",u.toString());
							}
						}
					}
				}
			}
			
		}
		return;
	}
    
	private boolean hasField = false;
	private Random rand = new Random();
	private int  max = 1000;// rand.nextInt(3);
	private int fieldCount = 0;
	private boolean FilterField(SootField field){
		if(field.isFinal())
			return true;
		String f = field.getType().toString();
		String n = field.getDeclaringClass().getName();
		String fn = field.getName();
		
		
		if(field.getName().contains(" this$")){
	        return true;			
		}
	    		
		return false;
	}

	private void scanMethodForApi(SootMethod m) {
		if (m.hasActiveBody()) {
			PatchingChain<Unit> units = m.getActiveBody().getUnits();
			for (Unit u : units) {
				Stmt s = (Stmt) u;
				if(iCfg.isCallStmt(s)){
					logger.info("    callStatement: {}",s.toString());
				}
			}
		}
	}
	private void scanMethodForApiExitField(SootMethod m) {
		if (m.hasActiveBody()) {
			PatchingChain<Unit> units = m.getActiveBody().getUnits();
			for (Unit u : units) {
				Stmt s = (Stmt) u;
		
				if(iCfg.isCallStmt(s)){
					logger.info("callStatement: {}",s.toString());
				}
				
				if(s.containsFieldRef()){
					activities.add(s.getFieldRef().getField().getDeclaringClass());
				    if(!FilterField(s.getFieldRef().getField())){
				    	//fieldCount++;
						PointsToSet pts = null;
						FieldRef ff = s.getFieldRef();
						allFields.add(ff.getField());

						if (ff instanceof InstanceFieldRef) {
							InstanceFieldRef iref = (InstanceFieldRef) ff;
							pts = getPointsToSet(iref.getBase());
						}else if (ff instanceof StaticFieldRef) {
							PointsToAnalysis pta = Scene.v().getPointsToAnalysis();
							synchronized (pta) {
							  pts = pta.reachingObjects(ff.getField());
							}
						}
						
						if(!ptsFields.containsKey(pts)){
							Set<SootField> fieldset = new HashSet<SootField>();
							fieldset.add(ff.getField());
							ptsFields.put(pts,fieldset);
						}else if(!ptsFields.get(pts).contains(ff.getField())){
							ptsFields.get(pts).add(ff.getField());
						}
				    }else
				    	logger.info("Filter out field: {}",s.getFieldRef().getField());
            	}
				
				if(s.containsInvokeExpr()){
					InvokeExpr invExpr = (InvokeExpr) s.getInvokeExpr();
					String mName = invExpr.getMethod().getName();
					String cName = invExpr.getMethod().getDeclaringClass().getName();
					if((mName.equals("exit")&&cName.equals("java.lang.System"))||
							(mName.equals("finish")&&cName.equals("android.app.Activity"))){
						exits.add(u);
						logger.info("exitStatement: {}, mname: {}, class: {}",s.toString(),	mName,cName);
						continue;
					}
					}
					if((cName.endsWith("OutputStream")||cName.endsWith("Writer"))&&mName.startsWith("write")){
						storeCalls.add(u);
						logger.info("storecallStatement: {}, mname: {}, class: {}",s.toString(),	mName,cName);
						//continue;
					}
					if((cName.endsWith("InputStream")||cName.endsWith("Reader"))&&mName.startsWith("read")){
						restoreCalls.add(u);
						logger.info("restorecallStatement: {}, mname: {}, class: {}",s.toString(),	mName,cName);
						//continue;
					}
				}
			}	
	}

	private InfoflowProblem getInfoflowProblem(final ISourceSinkManager sourcesSinks) {
		// Run the preprocessors
        for (Transform tr : preProcessors)
            tr.apply();
        
        int numThreads = Runtime.getRuntime().availableProcessors();
		CountingThreadPoolExecutor executor = createExecutor(numThreads);
		
		BackwardsInfoflowProblem backProblem;
		InfoflowSolver backSolver;
		final IAliasingStrategy aliasingStrategy;
		switch (aliasingAlgorithm) {
			case FlowSensitive:
				backProblem = new BackwardsInfoflowProblem(new BackwardsInfoflowCFG(iCfg), sourcesSinks);
				// need to set this before creating the zero abstraction
				backProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
				
				backSolver = new InfoflowSolver(backProblem, executor);
				backSolver.setJumpPredecessors(!computeResultPaths);

				aliasingStrategy = new FlowSensitiveAliasStrategy(iCfg, backSolver);
				break;
			case PtsBased:
				backProblem = null;
				backSolver = null;
				aliasingStrategy = new PtsBasedAliasStrategy(iCfg);
				break;
			default:
				throw new RuntimeException("Unsupported aliasing algorithm");
		}
		
		InfoflowProblem forwardProblem  = new InfoflowProblem(iCfg, sourcesSinks,
				aliasingStrategy);
		// need to set this before creating the zero abstraction
		forwardProblem.setFlowSensitiveAliasing(flowSensitiveAliasing);
		if (backProblem != null)
			forwardProblem.setZeroValue(backProblem.createZeroValue());
		
		// Set the options
		InfoflowSolver forwardSolver = new InfoflowSolver(forwardProblem, executor);
		aliasingStrategy.setForwardSolver(forwardSolver);
		//forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardSolver.setJumpPredecessors(!computeResultPaths);
		forwardProblem.setInspectSources(inspectSources);
		forwardProblem.setInspectSinks(inspectSinks);
		forwardProblem.setEnableImplicitFlows(enableImplicitFlows);
		forwardProblem.setEnableStaticFieldTracking(enableStaticFields);
		forwardProblem.setEnableExceptionTracking(enableExceptions);
		for (TaintPropagationHandler tp : taintPropagationHandlers)
			forwardProblem.addTaintPropagationHandler(tp);
		forwardProblem.setTaintWrapper(taintWrapper);
		forwardProblem.setStopAfterFirstFlow(stopAfterFirstFlow);
		forwardProblem.setIgnoreFlowsInSystemPackages(ignoreFlowsInSystemPackages);
		
		return forwardProblem;

	}
	
	/**
	 * Gets the points-to-set for the given value
	 * @param targetValue The value for which to get the points-to-set
	 * @return The points-to-set for the given value
	 */
	private PointsToSet getPointsToSet(Value targetValue) {
		PointsToAnalysis pta = Scene.v().getPointsToAnalysis();
		synchronized (pta) {			
			if (targetValue instanceof Local)
				return pta.reachingObjects((Local) targetValue);
			else if (targetValue instanceof InstanceFieldRef) {
				InstanceFieldRef iref = (InstanceFieldRef) targetValue;
				return pta.reachingObjects((Local) iref.getBase(), iref.getField());
			}
			else if (targetValue instanceof StaticFieldRef) {
				StaticFieldRef sref = (StaticFieldRef) targetValue;
				return pta.reachingObjects(sref.getField());
			}
			else if (targetValue instanceof ArrayRef) {
				ArrayRef aref = (ArrayRef) targetValue;
				return pta.reachingObjects((Local) aref.getBase());
			}
			else
				throw new RuntimeException("Unexpected value type for aliasing: " + targetValue.getClass());
		}
	}
	
	private boolean FilterAssignStmt(Unit u){
		String leftOp = ((AssignStmt)u).getLeftOp().toString();
		String rightOp = ((AssignStmt)u).getRightOp().toString();
		if(leftOp.contains(" this$")){
			logger.info("Filter out assignment1: {}",u);
	        return true;			
		}
		if(((AssignStmt)u).getRightOp().getType().toString().endsWith(".Activity")){
			logger.info("Filter out assignment13: {}",u);
	        return true;
		}
		return false;
	}
	
	private void scanMethodForAliasChanges(SootMethod m) {
			if (m.hasActiveBody()) {
				PatchingChain<Unit> units = m.getActiveBody().getUnits();
				for (Unit u : units) {
					if((u instanceof AssignStmt)){    
						PointsToSet ptsUnit=getPointsToSet(((AssignStmt)u).getLeftOp());
						boolean isChange=false;
						for (Map.Entry<PointsToSet,Set<SootField>> entry : ptsFields.entrySet()) {
							//if(aliasing.mayAlias(((AssignStmt)u).getLeftOp(), (Local)((InstanceFieldRef)(((Stmt)ch).getFieldRef())).getBase())){
							if(entry.getKey().hasNonEmptyIntersection(ptsUnit)){
								    changes.add(u);
								    isChange=true;
								    logger.info("changeStatement: {}, field:{}",u.toString(),entry.getValue());
								    for(SootField sootf : entry.getValue()){
								    	if(fieldChanges.containsKey(sootf))
								    		fieldChanges.get(sootf).add(u);
								    	else{
								    		Set<Unit> changeset = new HashSet<Unit>();
								    		changeset.add(u);
								    		fieldChanges.put(sootf, changeset);
								    	}
								    	if(changeFields.containsKey(u))
								    		changeFields.get(u).add(sootf);
								    	else{
								    		Set<SootField> fieldset = new HashSet<SootField>();
								    		fieldset.add(sootf);
								    		changeFields.put(u, fieldset);
								    	}
								    }
							}
						}
						if(!isChange){
							if((((AssignStmt)u).getLeftOp() instanceof FieldRef)){
								SootField sf = ((FieldRef)((AssignStmt)u).getLeftOp()).getField();
							    if(allFields.contains(sf)){
							    	isChange=true;
								    changes.add(u);
								    logger.info("changeStatement2: {}, field:{}",u.toString(),sf);
								    
								    if(fieldChanges.containsKey(sf))
								    		fieldChanges.get(sf).add(u);
								    else{
								    		Set<Unit> changeset = new HashSet<Unit>();
								    		changeset.add(u);
								    		fieldChanges.put(sf, changeset);
								    }
								    if(changeFields.containsKey(u))
								    		changeFields.get(u).add(sf);
								    else{
								    		Set<SootField> fieldset = new HashSet<SootField>();
								    		fieldset.add(sf);
								    		changeFields.put(u, fieldset);
								    }
							    }
						    }
						}
						if(!isChange)
							logger.info("Filter out assignment: {}",u);
					}
				}	
			}
	}
	
	
	@Override
	public InfoflowResults getResults() {
		return results;
	}

	@Override
	public boolean isResultAvailable() {
		if (results == null) {
			return false;
		}
		return true;
	}
	
	public static int getAccessPathLength() {
		return accessPathLength;
	}
	
	/**
	 * Sets the maximum depth of the access paths. All paths will be truncated
	 * if they exceed the given size.
	 * @param accessPathLength the maximum value of an access path. If it gets longer than
	 *  this value, it is truncated and all following fields are assumed as tainted 
	 *  (which is imprecise but gains performance)
	 *  Default value is 5.
	 */
	public static void setAccessPathLength(int accessPathLength) {
		Infoflow.accessPathLength = accessPathLength;
	}
	
	/**
	 * Sets whether results (source-to-sink connections) that only differ in their
	 * propagation paths shall be merged into a single result or not.
	 * @param pathAgnosticResults True if two results shall be regarded as equal
	 * if they connect the same source and sink, even if their propagation paths
	 * differ, otherwise false
	 */
	public static void setPathAgnosticResults(boolean pathAgnosticResults) {
		Infoflow.pathAgnosticResults = pathAgnosticResults;
	}
	
	/**
	 * Gets whether results (source-to-sink connections) that only differ in their
	 * propagation paths shall be merged into a single result or not.
	 * @return True if two results shall be regarded as equal if they connect the
	 * same source and sink, even if their propagation paths differ, otherwise
	 * false
	 */
	public static boolean getPathAgnosticResults() {
		return Infoflow.pathAgnosticResults;
	}
	
	/**
	 * Gets whether recursive access paths shall be reduced, e.g. whether we
	 * shall propagate a.[next].data instead of a.next.next.data.
	 * @return True if recursive access paths shall be reduced, otherwise false
	 */
	public static boolean getUseRecursiveAccessPaths() {
		return useRecursiveAccessPaths;
	}

	/**
	 * Sets whether recursive access paths shall be reduced, e.g. whether we
	 * shall propagate a.[next].data instead of a.next.next.data.
	 * @param useRecursiveAccessPaths True if recursive access paths shall be
	 * reduced, otherwise false
	 */
	public static void setUseRecursiveAccessPaths(boolean useRecursiveAccessPaths) {
		Infoflow.useRecursiveAccessPaths = useRecursiveAccessPaths;
	}
	
	/**
	 * Adds a handler that is called when information flow results are available
	 * @param handler The handler to add
	 */
	public void addResultsAvailableHandler(ResultsAvailableHandler handler) {
		this.onResultsAvailable.add(handler);
	}
	
	/**
	 * Adds a handler which is invoked whenever a taint is propagated
	 * @param handler The handler to be invoked when propagating taints
	 */
	public void addTaintPropagationHandler(TaintPropagationHandler handler) {
		this.taintPropagationHandlers.add(handler);
	}
	
	/**
	 * Removes a handler that is called when information flow results are available
	 * @param handler The handler to remove
	 */
	public void removeResultsAvailableHandler(ResultsAvailableHandler handler) {
		onResultsAvailable.remove(handler);
	}
	
	@Override
	public void setIPCManager(IIPCManager ipcManager) {
	    this.ipcManager = ipcManager;
	}
}
